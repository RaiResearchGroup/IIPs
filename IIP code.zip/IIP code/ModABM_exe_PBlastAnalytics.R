# Modular Solar ABM analysis file
# D. Cale Reeves
# UT Austin, Energy Systems Transformation Group
# Last edit: 05/22/2017
#
# 
#---------------#
# Run Parameters ---- change to run for the models you want to compare
#---------------#
#setwd("/Users/matthewhaley/Box\ Sync/Code_InfoIntervention_MH/FROM\ TACC/Code_InfoIntervention_MH")
agentCSVpath = "inputs/ATXAgents.csv" 
EmpQuarters = 22

#----------re do 17

CompareModelNumber <- c(200002) 
CompareDescription <- c("PTALK HighK - 500 SEEDS- Training Off") 
outDir = ("outputs/")
runlogDir = ("runlogs/")



#-------------------------#
# Import Libraries
#-------------------------#

print("[Anls]          Loading Libraries ...")

library(ggplot2)
library(lubridate)
library(reshape2)
library(scales)

print("[Anls]          ... Libraries Loaded")

#---------------#
# Build empiricals from agents 
#---------------#

print(sprintf("[Anls]          Building empirical comparison from: %s for %d Quarters", agentCSVpath, EmpQuarters))
print("[Anls]          Reading Agent Empiricals")
agents <- read.csv(as.character(agentCSVpath))

print("[Anls]          Calculating Empiricals...")
agents <- agents[agents$AdoptDate != "", ]
agents$AdoptDate = as.Date(agents$AdoptDate, "%m/%d/%y")
agents <- agents[order(agents$AdoptDate), ]
agents$initialAdopter[agents$AdoptDate < as.Date("01/01/2008", "%m/%d/%Y")] = 1 #Set initial adopters to those that adopt before 2008
agents$adopter <- 1

agents$adoptyear <- year(agents$AdoptDate)
agents$adoptmonth <- month(agents$AdoptDate)
agents$adoptquarter <- quarter(agents$AdoptDate)
agents$adoptyearquart <- paste(agents$adoptyear, agents$adoptquarter, sep="")

quartagg <- aggregate(adopter ~ adoptyearquart, data=agents, sum)

sumInitAdopts <- sum(quartagg$adopter[quartagg$adoptyearquart < 20080])

quartagg <- quartagg[quartagg$adoptyearquart > 20080, ]

#sumInitAdopts
#quartagg

NewAdopts = c(sumInitAdopts, quartagg$adopter)

NewAdopts <- NewAdopts[0:EmpQuarters+1]



Empirics <- data.frame(Quarter = seq(0, EmpQuarters), NewAdopts = NewAdopts)



Empirics$CumulAdopts <- cumsum(Empirics$NewAdopts)

tmpCumul <- Empirics$CumulAdopts[1:length(Empirics$CumulAdopts)-1]
tmpNewAd <- Empirics$NewAdopts[2:length(Empirics$NewAdopts)]

#tmpCumul
#tmpNewAd

Empirics$EmpGrowRate <- c(0, tmpNewAd/tmpCumul)

Empirics$Model <- "Empirical"
#omit initial conditions (quarter 0)
Empirics <- Empirics[Empirics$Quarter != 0,]


# head(Empirics)
# tail(Empirics)

Empirical_Total_Adopts <- max(Empirics$CumulAdopts)
#Empirical_Total_Adopts <- 2709

print("[Anls]          ...Empiricals Calculated")
print(sprintf("[Anls]          ...Total Empirical Adoptions: %d", Empirical_Total_Adopts))



#---------------#
# Get compare models RunOuts
#---------------#

print("[Anls]          Reading Models to compare")


print(sprintf("[Anls]          Compare Models:%s, Model Descriptions: %s", CompareModelNumber, CompareDescription))

print("[Anls]          Finding Comparison Model Output files")

BatchRunLog <- data.frame()
for(i in 1:length(CompareModelNumber)) {
	Out_pattern = sprintf("RunOuts_ModABM_ParamBlast_%s_job", CompareModelNumber[i])
	Outfiles = unlist(lapply(Out_pattern, function(x){list.files(path = outDir, pattern =x)}))
	for(j in 1:length(Outfiles)) {
		print(sprintf("[Anls]          Reading Model Run Output File:%s", Outfiles[j]))
		tmpRunLog <- read.csv(file = sprintf("%s/%s", outDir, Outfiles[j]))
		tmpRunLog$JobID <- j
		BatchRunLog <<- rbind(BatchRunLog, tmpRunLog)
	}	
}
BatchRunLog$uniqueRunID <- paste(BatchRunLog$ModelNum, BatchRunLog$JobID, BatchRunLog$subModelID, sep="-")

# head(BatchRunLog)
# tail(BatchRunLog)

#---------------#
# Get compare models ParamLogs
#---------------#

print("[Anls]          Reading Model Parameter Logs")


print(sprintf("[Anls]          Compare ParamLogs:%s, Model Descriptions: %s", CompareModelNumber, CompareDescription))

print("[Anls]          Finding Comparison Model Parameter Logs files")

BatchParamLog <- data.frame()
for(i in 1:length(CompareModelNumber)) {
	Out_pattern = sprintf("ParamLog_ModABM_ParamBlast_%s_job", CompareModelNumber[i])
	Outfiles = unlist(lapply(Out_pattern, function(x){list.files(path = runlogDir, pattern =x)}))
	for(j in 1:length(Outfiles)) {
		print(sprintf("[Anls]          Reading Model Parameter Log File:%s", Outfiles[j]))
		tmpParamLog <- read.csv(file = sprintf("%s/%s", runlogDir, Outfiles[j]))
		tmpParamLog$JobID <- j
		BatchParamLog <<- rbind(BatchParamLog, tmpParamLog)
	}	
}
# 
# head(BatchParamLog)
# tail(BatchParamLog)


BatchParamLog$uniqueRunID <- paste(BatchParamLog$Model, BatchParamLog$JobID, BatchParamLog$subModelID, sep="-")


#---------------#
# Merge Parameter Logs to Run Outs
#---------------#

Run_Param_DF <- merge(BatchRunLog, BatchParamLog, by="uniqueRunID")

# nrow(Run_Param_DF)
# head(Run_Param_DF)
# tail(Run_Param_DF)
# 
# q()

Run_Param_DF$AdditionalAdopts <- Run_Param_DF$TotalAdopts - Empirical_Total_Adopts

M1 <- lm(AdditionalAdopts ~ PTALK_howManySEEDS + PTALK_FollowOn_Rate,Run_Param_DF)
summary(M1)
library(stargazer)
stargazer(M1)

#summary(lm(AdditionalAdopts ~ CELEB_howManySEEDS + CELEB_FollowOn_Rate,Run_Param_DF))





print("this is max(Run_Param_DF$AdditionalAdopts)")
max(Run_Param_DF$AdditionalAdopts)

print("this is min(Run_Param_DF$AdditionalAdopts)")
min(Run_Param_DF$AdditionalAdopts)

#	#-------  For 500 Seeds
#	PhaseDiagram_manual <- data.frame(X=rep(seq(12.5, 487.5, by=25), 20))
#
#
#	PhaseDiagram_manual$Y <- rep(seq(0.025, 0.975, by=0.05), each=20)
#
#	PhaseDiagram_manual$Z <- mapply(function (x,y) mean(Run_Param_DF$AdditionalAdopts[Run_Param_DF$CHAMP_howManySEEDS >= x-12.5 & Run_Param_DF$CHAMP_howManySEEDS < x+12.5 & Run_Param_DF$CHAMP_FollowOn_Rate >= y-0.025 & Run_Param_DF$CHAMP_FollowOn_Rate < y+0.025]), 
#		PhaseDiagram_manual$X, PhaseDiagram_manual$Y) 
#
#	# 
#	# -------  For 20 Seeds
#	# PhaseDiagram_manual <- data.frame(X=rep(seq(1, 20), 20))
#	# 
#	# 
#	# PhaseDiagram_manual$Y <- rep(seq(0.025, 0.975, by=0.05), each=20)
#	# 
#	# PhaseDiagram_manual$Z <- mapply(function (x,y) mean(Run_Param_DF$AdditionalAdopts[Run_Param_DF$PHAMB_howManySEEDS == x & Run_Param_DF$PHAMB_FollowOn_Rate >= y-0.025 & Run_Param_DF$PHAMB_FollowOn_Rate < y+0.025]), 
#	# 	PhaseDiagram_manual$X, PhaseDiagram_manual$Y) 
#
#
#
#	# PhaseDiagram_manual
#
PhaseDiagramPlotName = sprintf("PhaseDiagram2_%s.png", CompareModelNumber)
#
#	PhaseDiagramPlot <- ggplot(data=PhaseDiagram_manual, aes(x = X, y  = Y, z=Z, fill=Z)) +
#		geom_tile(data=PhaseDiagram_manual, aes(x = X, y  = Y, z=Z, fill=Z)) +
#	# 	scale_fill_gradient(low="green", high="red", name="Additional\nAdoptions") +
#	# 	scale_fill_gradient2(limits=c(-1000,6500), breaks=c(-300, 0, 1000,2000,3000,4000,5000,6000), low="blue", mid="green", high="red", midpoint=0, name="Additional\nAdoptions") +
#		scale_fill_gradientn(limits=c(-600,8000), breaks=c(-500, 0, 1000,2000,3000,4000,5000,6000,7000,8000), colors=c("blue","green","yellow","red"), values=c(0,0.05,0.11,1), name="Additional\nAdoptions") +
#		guides(alpha=FALSE,fill= guide_colorbar(barheight=28)) + 
#		scale_x_continuous(name="Seeds") +
#		scale_y_continuous(name="Follow-on") +
#		ggtitle(CompareDescription) + 
#		theme_bw()

PhaseDiagramPlot <- ggplot(data=Run_Param_DF, aes(x = ECONOMIC_howManySEEDS, y  = AdditionalAdopts)) +
	geom_point(size = 1, alpha = .4, position = "jitter")+
	stat_smooth() +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Seeds") +
	scale_y_continuous(name="Additional Adoptions") +
	ggtitle(CompareDescription) + 
	theme_bw()


	
ggsave(PhaseDiagramPlotName, PhaseDiagramPlot, path = "analytics/graphics/")	



q()
































kde2d.weighted <- function (x, y, w, h, n = n, lims = c(range(x), range(y))) {
  nx <- length(x)
  if (length(y) != nx) 
      stop("data vectors must be the same length")
  gx <- seq(lims[1], lims[2], length = n) # gridpoints x
  gy <- seq(lims[3], lims[4], length = n) # gridpoints y
  if (missing(h)) 
    h <- c(bandwidth.nrd(x), bandwidth.nrd(y));
  if (missing(w)) 
    w <- numeric(nx)+1;
  h <- h/4
  ax <- outer(gx, x, "-")/h[1] # distance of each point to each grid point in x-direction
  ay <- outer(gy, y, "-")/h[2] # distance of each point to each grid point in y-direction
  z <- (matrix(rep(w,n), nrow=n, ncol=nx, byrow=TRUE)*matrix(dnorm(ax), n, nx)) %*% t(matrix(dnorm(ay), n, nx))/(sum(w) * h[1] * h[2]) # z is the density
  return(list(x = gx, y = gy, z = z))
}

print(sprintf("PhaseDiagram: This wide across the X: %f", min(Run_Param_DF$CHAMP_AMB_howMany) - max(Run_Param_DF$CHAMP_AMB_howMany)))

print(sprintf("PhaseDiagram: This tall up the Y: %f", max(Run_Param_DF$CHAMP_TargetparticipationRate) - min(Run_Param_DF$CHAMP_TargetparticipationRate)))


min(Run_Param_DF$CHAMP_AMB_howMany)
max(Run_Param_DF$CHAMP_AMB_howMany)
min(Run_Param_DF$CHAMP_TargetparticipationRate)
max(Run_Param_DF$CHAMP_TargetparticipationRate)



XRange = c(min(Run_Param_DF$CHAMP_AMB_howMany), max(Run_Param_DF$CHAMP_AMB_howMany))
YRange = c(min(Run_Param_DF$CHAMP_TargetparticipationRate), max(Run_Param_DF$CHAMP_TargetparticipationRate))





# str(LongRange)
# print("that was str longrange")

# Calculate the 2d density estimate over the common range


N_dens <- 15

XIncrement <- (max(XRange)-min(XRange))/N_dens
YIncrement <- (max(YRange)-min(YRange))/N_dens




PhaseDiagram = kde2d.weighted(Run_Param_DF$CHAMP_AMB_howMany, Run_Param_DF$CHAMP_TargetparticipationRate, Run_Param_DF$TotalAdopts, h=c(5*XIncrement, 5*YIncrement) , lims=c(XRange, YRange), n=N_dens)

PhaseDiagram.m = melt(PhaseDiagram$z, id.var=rownames(PhaseDiagram))
names(PhaseDiagram.m) = c("X","Y","z")

head(PhaseDiagram.m)



PhaseDiagram.m$adjX<- (PhaseDiagram.m$X * XIncrement) + min(XRange)
PhaseDiagram.m$adjY <- (PhaseDiagram.m$Y * YIncrement) + min(YRange)
PhaseDiagram.m$adjz <- rescale(PhaseDiagram.m$z, to = c(0,1))
PhaseDiagram.m$STDadjz <- scale(PhaseDiagram.m$z)
print(sprintf("Phase diagram calculated for a %d square grid", N_dens))


PhaseDiagramPlotName = "PhaseDiagram_CHAMP.png"

PhaseDiagramPlot <- ggplot(data=PhaseDiagram.m, aes(x = adjX, y  = adjY, z=STDadjz, fill=STDadjz)) +
#	geom_point(data = agents, aes(x = WGSlong, y = WGSlat), shape = 16, size = 0.6) + 
	geom_tile(data=PhaseDiagram.m, aes(x = adjX, y  = adjY, z=STDadjz, fill=STDadjz)) +
#	geom_contour(data=PBCEmpirical100.m, aes(x = adjLong, y  = adjLat, z=STDadjz)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
 	scale_fill_gradient(low="green", high="red", name="Additinoal\nAdoptions") +
  	coord_cartesian(xlim=XRange, ylim=YRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Seeds") +
	scale_y_continuous(name="Follow-on") +
	theme_bw()

	
ggsave(PhaseDiagramPlotName, PhaseDiagramPlot, path = "analytics/graphics/")	

	


q()
















print("[Anls]          Calculating Comparison Model Error...")

Comparison <- aggregate(CumulAdopts ~ ModelNum + Quarter, data = BatchQuartLog, mean)
colnames(Comparison)[3] = "MeanCumulAdopts"

Comparison$MeanNewAdopts <- aggregate(NewAdopts ~ ModelNum + Quarter, data = BatchQuartLog, mean)$NewAdopts
Comparison$MeanEmpGrowRate <- aggregate(EmpGrowRate ~ ModelNum + Quarter, data = BatchQuartLog, mean)$EmpGrowRate

Comparison <- Comparison[order(Comparison$ModelNum, Comparison$Quarter), ]

Comparison$CumulAdoptsSQError <- (Comparison$MeanCumulAdopts - Empirics$CumulAdopts)^2
Comparison$NewAdoptsSQError <- (Comparison$MeanNewAdopts - Empirics$NewAdopts)^2
Comparison$EmpGrowRateSQError <- (Comparison$MeanEmpGrowRate - Empirics$EmpGrowRate)^2


#head(Comparison)
#Comparison

Errors <- aggregate(CumulAdoptsSQError ~ ModelNum, data = Comparison, mean)
colnames(Errors)[2] = "CumulAdoptsMSE"
Errors$NewAdoptsMSE <- aggregate(NewAdoptsSQError ~ ModelNum, data = Comparison, mean)$NewAdoptsSQError
Errors$EmpGrowRateMSE <- aggregate(EmpGrowRateSQError ~ ModelNum, data = Comparison, mean)$EmpGrowRateSQError

Errors$CumulAdoptsRMSE <- sqrt(Errors$CumulAdoptsMSE)
Errors$NewAdoptsRMSE <- sqrt(Errors$NewAdoptsMSE)
Errors$EmpGrowRateRMSE <- sqrt(Errors$EmpGrowRateMSE)

#head(Errors)
#Errors

print("[Anls]          ... Model Error Calculated")
ModelErrorsFile = sprintf("analytics/ModABM_Errors_%s.csv", paste(CompareModelNumber, collapse="-"))

print(sprintf("[Anls]          Writing Model Errors to %s", ModelErrorsFile))

write.csv(Errors, ModelErrorsFile, row.names=FALSE)


#---------------#
# Make graphic of cumulative installations
#---------------#

BatchQuartLog$Model <- as.factor(BatchQuartLog$ModelNum)
CumAdoptsPlotPathName = sprintf("analytics/graphics/ModABM_CumAdopts_%s.png", paste(CompareModelNumber, collapse="-"))
#CumAdoptsPlotPathName

png(CumAdoptsPlotPathName, width = 7, height = 7, res = 300, units = 'in', pointsize = 13)	
ggplot(data = BatchQuartLog) +
		geom_point(aes(x = Quarter, y = CumulAdopts, color = Model), size = 1, alpha = .4, position = "jitter")+
		stat_smooth(aes(x = Quarter, y = CumulAdopts, fill = Model, color = Model, group = interaction(Model)), alpha = .7, 
			position = "identity", method = 'gam', formula = y ~ s(x,k=11), show.legend = FALSE, size = 2, level = 0)+	
		geom_point(data = Empirics, aes(x = Quarter, y = CumulAdopts), size = 2) +
		geom_line(data = Empirics, aes(x = Quarter, y = CumulAdopts), color = "darkgoldenrod1", size = 1.5) +
		ggtitle(sprintf("Cumulative adoptions comparison across %s models.", length(CompareModelNumber))) + 
		ylab("Cumulative Number of PV Systems") +
		guides(color = guide_legend(override.aes = list(alpha = .9, size = 5), keywidth = 1.5, keyheight = 1.5,
			fill = FALSE, title = "Model", title.theme = element_text(size = 15, face = 'bold', angle = 0), label.theme = element_text(size = 15, angle = 0))) +
		scale_x_continuous("", breaks= seq(0,EmpQuarters), 
			labels=c("","2008","","","","2009","","","","2010","","","",
				"2011","","","","2012","","","","2013","","","")) +
		theme_bw() + 
		theme(legend.justification=c(0,1), legend.position=c(0,1), panel.grid.minor = element_blank(), 
			panel.grid.major = element_blank(), axis.text = element_text(face = 'bold', size = 15, angle =0),
			axis.title = element_text(face = 'bold', size = 16, angle = 0))

dev.off()




