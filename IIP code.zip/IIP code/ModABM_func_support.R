# Modular Solar ABM Support Functions
# D. Cale Reeves
# UT Austin, Energy Systems Transformation Group
# Last edit: 05/22/2017
#
# 



#-----------------------------#
# Load libraries
#-----------------------------#
if (params$SocNetInitMod == "SECAD") {
	library("fastmatch")
}
	


#-----------------------------#
# Debugging verbosity
#-----------------------------#

if ("Control" %in% as.list(strsplit(as.character(params$dBug), ";"))[[1]]) {
	print("[Support] Control Debug on")
	dBugControl = function (m) {print(m)}
} else { dBugControl = function (m) {} } 

if ("Init" %in% as.list(strsplit(as.character(params$dBug), ";"))[[1]]) {
	print("[Support] Init Debug on")
	dBugInit = function (message) {print(message)}
} else { dBugInit = function (m) {} } 

if ("Stage" %in% as.list(strsplit(as.character(params$dBug), ";"))[[1]]) {
	print("[Support] Stage Debug on")
	dBugStage =function (m) {print(m)}
} else { dBugStage = function (m) {} } 

if ("Run" %in% as.list(strsplit(as.character(params$dBug), ";"))[[1]]) {
	print("[Support] Run Debug on")
	dBugRun =function (m) {print(m)}
} else { dBugRun = function (m) {} } 

if ("Quarter" %in% as.list(strsplit(as.character(params$dBug), ";"))[[1]]) {
	print("[Support] Quarter Debug on")
	dBugQuarter = function (m) {print(m)}
} else { dBugQuarter = function (m) {} } 

if ("Step" %in% as.list(strsplit(as.character(params$dBug), ";"))[[1]]) {
	print("[Support] Step Debug on")
	dBugStep = function (m) {print(m)}
} else { dBugStep = function (m) {} } 

if ("Substep" %in% as.list(strsplit(as.character(params$dBug), ";"))[[1]]) {
	print("[Support] Substep Debug on")
	dBugSubstep = function (m) {print(m)}
} else { dBugSubstep = function (m) {} } 

if ("Outs" %in% as.list(strsplit(as.character(params$dBug), ";"))[[1]]) {
	print("[Support] Output Debug on")
	dBugOuts = function (m) {print(m)}
} else { dBugOuts = function (m) {} } 

if ("Intervention" %in% as.list(strsplit(as.character(params$dBug), ";"))[[1]]) {
	print("[Support] Intervention Debug on")
	dBugIntv = function (m) {print(m)}
} else { dBugIntv = function (m) {} } 


