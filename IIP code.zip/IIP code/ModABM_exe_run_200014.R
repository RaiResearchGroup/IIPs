# Modular Solar ABM Runcution/Parameter/Tracking file
# D. Cale Reeves
# UT Austin, Energy Systems Transformation Group
# Last edit: 09/29/2017
#
#
# 
#-------------------------#
#Track Runs/Results
#-------------------------#

#----Model number convention 
#----Model number convention 
#--First digit: Author: 1 for Cale
#--second to 6th digits: "name" of the run

# 100001[done] = Baseline on stampede 2 - no interventions 
#
# 100002[done] = PBLAST on stampede 2 - PHAMB HighK - 500 SEEDS 
# 100003[] = PBLAST on stampede 2 - PHAMB Random - 500 SEEDS 
# 100004[] = PBLAST on stampede 2 - CELEB Random - 500 SEEDS 
# 100005[] = PBLAST on stampede 2 - PTALK Random - 500 SEEDS- Training Off 
# 100006[] = PBLAST on stampede 2 - PTALK Random - 500 SEEDS- Training On 
# 100007[] = PBLAST on stampede 2 - PTALK HighK - 500 SEEDS- Training On 
# 100008[] = PBLAST on stampede 2 - PTALK HighK - 500 SEEDS- Training Off 
# 100009[] = PBLAST on stampede 2 - CHAMP Random - 500 SEEDS- Training Off 
# 100010[] = PBLAST on stampede 2 - CHAMP Random - 500 SEEDS- Training On 
# 100011[] = PBLAST on stampede 2 - CHAMP HighK - 500 SEEDS- Training On 
# 100012[] = PBLAST on stampede 2 - CHAMP HighK - 500 SEEDS- Training Off 
# 100013[] = PBLAST on stampede 2 - ECON Random - 500 SEEDS- Training Off 
# 100014[] = PBLAST on stampede 2 - ECON HighK - 500 SEEDS- Training Off 
 



#-------------------------#
# Command Line Arguments
#-------------------------#
# Variables passed from solarABMjob bash script

args = commandArgs(TRUE)

#-------------------------#
#Define Model Runtime Parameters
#-------------------------#
paramsDF = data.frame(
  # - Identification parameters ------------------------------
  job = args[1],
  Model = 200014, 									# Used as a outfile designation. Remember to change and log as parameters are altered.
  ModelType = "ParamBlast",								#Regular, ParamBlast?
  batches = 20, 											# Number of batches - batches can have different initial values
  runs = 1,												# Number of runs in a batch - runs share an intialization
  Quarters = 24, 											# Number of ticks in a run. set to quarters 
  dBug = as.character("Off"), 							# Route debugging output to stdout? Separate with ; .Choose from list(c("Control;Init;Stage;Run;Quarter;Step;Substep;Outs;Intervention;Off")
  # - Initialization Modules ---------------------------------
  AgentInitMod = "SECAD",									# Specifies an agent initialization module. One of c("SECAD")
  SocNetInitMod = "SECAD",								# Specifies a social network initialization module. One of c("SECAD", "NPaths")
  SeedAdopters = "Off", 									# Use seeded adopters during initialization?
  # -	Runtime Modules ----------------------------------------
  RuntimeInitMod = "SECAD",								# Specifies runtime initialization modules. One of c("SECAD")
  AdoptRunMod = "SECAD", 									# Specifies the adoption determining module. One of c("SECAD")
  ProdInc_budget = "Off", 								# Impose a budget contraint on Production incentives?
  # - Outputs Modules ----------------------------------------
  RunsOut = "On", 										# Generate summaries for each run? 
  QuartersOut = "On", 									# Generate summary measures by quarter? 
  FollowOnsOut = "On", 									# Generate total follow-ons (interventions) for each run? 
  AdoptionsOut = "On", 									# Generate adoption time/space/threshold output? 
  SocNetOut = "Off", 										# Generate Social Network output? 
  ErrorOut = "Off", 										# Generate Run-level summary of error?
  # - ########################################################
  # - ###
  # - ###			Initialization Module Specific Parameters
  # - ###
  # - ########################################################
  # - SECAD Agent Initialization Module ----------------------
  SECADagentCSVpath = "inputs/ATXAgents.csv", 			# Agent state variables, includes HomeValue	AdoptDate	radMEANft	hhIndex	WGSlat	WGSlong	SIA	U	PBC
  # - SECAD Social Network Initialization Module -------------
  SECADGeoNei = "inputs/ATXGeoNeiDF.Rdata",				# Path for neighbors file
  SECADcalcLocals = FALSE,								# Re-calculate locals?
  SECAD_FIT_lambda = 0.1,									# Random wiring parameter for SWN
  
  # - ########################################################
  # - ###
  # - ###			Runtime Module Specific Parameters
  # - ###
  # - ########################################################
  # - SECAD Adoption Runtime Module --------------------------
  SECADEconData = "inputs/ATXSecadEcon.csv", 				# SECAD module Econ data includes: Loess	Tick	SD	Rebate_d_w	Elec_VOC
  SECAD_FIT_steps = 4, 									# number of steps per tick - a step is an opportunity to update SIA
  SECADEconRebateCoefficient = .9556, 					# AE does not give full STC rating credit to panels, but 95%
  SECADEconfedITC = .3,									# Investment Tax Credit
  SECAD_FIT_PBCscaler_a0 = -60.61,							# Scaling parameters to align PBC with PP
  SECAD_FIT_PBCscaler_a1 = 2.46,							# Scaling parameters to align PBC with PP
  SECADAttitudeModule = "On",								# Run SECAD with Attitude module?
  SECAD_FIT_mu = 0.38, 									# Opinion convergence parameter
  SECAD_FIT_siaThresh = 0.6,								# SIA threshold for attitude activation
  # - ########################################################
  # - ###
  # - ###			Output Module Specific Parameters
  # - ###
  # - ########################################################
  
  # - ########################################################
  # - ###
  # - ###			Intervention Control Parameters
  # - ###
  # - ########################################################
  
#### CELEB Intervention
CELEB_doQuarters_vec = as.character("Off"),				# How often to do CELEB intervention? Separate Integers with ;
CELEB_howToChoose = c("Random"),						# How do we choose our champions? are c("Random", "HighK") - NB DO NOT RUN HK IT IS IRRELEVANT
CELEB_howManySEEDS = c(20),                #this is number of champions (seeds)
CELEB_RA = c("Relative Agreement"),         # options are  c("Static","Relative Agreement") -  this defines how the champ RA algorithm will work.simple is simply set any agent that knows a champ straight to 0.6. Champ Preferential is the normal RA algorithm but the agent will always interact with a champ if it is a neighbor
CELEB_FollowOn_Rate = 0.1,            #this is the follow on rate
CELEB_Training = as.character("Off"),

#### PHAMB Intervention
PHAMB_doQuarters_vec = as.character("Off"),				# How often to do CELEB intervention? Separate Integers with ;
PHAMB_howToChoose = c("Random"),					# options are c("Random", "HighK")
PHAMB_howToConnectAMB = c("Random"),					# options are c("Random") 
PHAMB_howManySEEDS = 20,							# this is number of ambassadors (seeds)
PHAMB_FollowOn_Rate = 0.1,						# percentage of potential adopters that demonstrate interest - this is the follow on rate
#PHAMB_TargetSIAThresholdADJ = 0.6,						# coefficient multiplier of SIA that determines targets are interested in the program
#PHAMB_EdgeCount = 2,									# number of potential new edges - corresponds to how many phone numbers you give a target
PHAMB_Training = as.character("Off"),

#### PTALK Intervention
PTALK_doQuarters_vec = as.character("Off"),				# How often to do CELEB intervention? Separate Integers with ;
PTALK_howToChoose = c("HighK"),  # options are c("Random" & "HighK")
PTALK_Training = as.character("Off"),       # options are  c("On","Off") - if training is on we increase PAT sia by: PAT SIA + 0.5*(1-PAT SIA)
PTALK_howManySEEDS = 20,           #this is number of seeds
PTALK_howtoUpdate = c("Relative_Agreement"),    # Options are c("Static" & "Relative_Agreement")
PTALK_FollowOn_Rate = 0.1,                      #this is the follow on rate

### Champ Intervention
CHAMP_doQuarters_vec = as.character("Off"),				# How often to do CELEB intervention? Separate Integers with ;
CHAMP_RA = c("Relative Agreement"),                         # options are  c("Static","Relative Agreement") -  this defines how the champ RA algorithm will work.simple is simply set any agent that knows a champ straight to 0.6. Champ Preferential is the normal RA algorithm but the agent will always interact with a champ if it is a neighbor
CHAMP_howToChoose = c("HighK"),   #options are c("Random","HighK")
CHAMP_Training = as.character("Off"),       # options are  c("On","Off") - if training is on we increase champ sia by CHAMP SIA + 0.5*(1-CHAMP SIA)
CHAMP_howManySEEDS = c(20), #thiis is the number of seeds 
#CHAMP_SIAthreshold = 0.6,
CHAMP_FollowOn_Rate = 0.1, #this is the participation rate of follow ons

### Economic Intervention
ECONOMIC_doQuarters_vec = as.character("1"), # How often to do econ intervention? Separate Integers with ;
ECONOMIC_howManySEEDS = c(10),                #thiis is the number of seeds 
ECONOMIC_howToChoose = c("HighK"),    #options are c("Random","HighK")
ECONOMIC_FollowOn_Rate = NA	, #this is the participation rate of follow ons
ECONOMIC_Training = as.character("Off"),       # options are  c("On","Off") - if training is on we increase champ sia by CHAMP SIA + 0.5*(1-CHAMP SIA)

# - ########################################################
# - ###
# - ###			End Of ParamsDF
# - ###
# - ########################################################
ender = 0)


# - ########################################################
# - ###
# - ###			Set up Logging
# - ###
# - ########################################################

LogFile = sprintf("runlogs/Log_ModABM_%s_%s_job%s.txt", paramsDF$ModelType[1], paramsDF$Model[1], paramsDF$job[1])
sink(LogFile, append=FALSE, type=c("output", "message"))

# - ########################################################
# - ###
# - ###			Expand Parameter DF, Backfitting Control, Param Writing
# - ###
# - ########################################################
#-------------------------#
# Expand Params DF, set params to paramsDF[1]
#-------------------------#
paramsDF$TotalRuns <- paramsDF$batches*paramsDF$runs
paramsDF <- paramsDF[rep(row.names(paramsDF), paramsDF$TotalRuns), ]
params <- paramsDF[1, ]
paramsDF$subModelID <- paste(rep(1:params$batches, each=params$runs), rep(seq(1, params$runs), params$batches), sep=":")

#-------------------------#
# Set up backfitting
#-------------------------#
print(sprintf("[Run]     Model Type is %s", params$ModelType))
if (params$ModelType == "ParamBlast") {
  print("[Run]     This is a ParamBlast run")
  print("[Run]     ParamBlast variables: PHAMB_howManySEEDS")
  print("[Run]     ParamBlast variables: PHAMB_FollowOn_Rate")
  print("[Run]     Generating random values...")
  paramsDF$ECONOMIC_howManySEEDS <- floor(runif(nrow(paramsDF), 1, 501))
#  paramsDF$CHAMP_FollowOn_Rate <- runif(nrow(paramsDF), 0, 1)
  print("[Run]     ... Values Generated")
}


#-------------------------#
# Write out parameters 
#-------------------------#
write.csv(paramsDF, sprintf("runlogs/ParamLog_ModABM_%s_%s_job%s.csv", params$ModelType, params$Model, params$job), row.names=FALSE)

########################################################
###
###			End Of Runtime setup/parametization
###
########################################################


########################################################
###
###			Load Libraries
###
########################################################
print("[Run]     Loading Libraries...")

source("ModABM_func_support.R")
print("[Run]          Support Library loaded... ")

source("ModABM_func_init.R")
print("[Run]          Initialization Library loaded... ")

source("ModABM_func_core.R")
print("[Run]          Core Library loaded... ")

print("[Run]     Libraries Loaded Successfully")

print("[Run]     Determining Output Initialization...")
if (params$RunsOut == "On") {
  RunOuts <<- NULL
}

if (params$QuartersOut == "On") {
  QuarterOuts <<- NULL
}

if (params$FollowOnsOut == "On") {
  FollowOnsOut <<- NULL
}

print("[Run]     Outputs Initialized")

########################################################
###
###			Runtime Orders
###
########################################################




for (b in 1:params$batches){ 
  print(sprintf("[Run]     Initializing batch: %d", b))
  initModel()
  if (params$SocNetOut == "On") {
    if (params$SocNetInitMod == "SECAD") {
      SocNet = data.frame(agentIndex = SECADagentIndex_vec)
      SocNet$Alters = SECADAlter_vec
      save(SocNet, file=sprintf("outputs/SocNet_ModABM_%s_%s_b%d_job%s.Rdata", params$ModelType, params$Model, b, params$job) )
    }#------End of SECAD Social Net init check
  }#------End of SocNetOut check
  
  for (r in 1:params$runs){ 
    subModelID <- paste(b,r, sep=":")
    print(sprintf("[Run]     Running run: %d of batch: %d; subModelID: %s", r, b, subModelID))
    print(sprintf("[Run]     Setting params for subModelID: %s", subModelID))
    params <- paramsDF[paramsDF$subModelID == subModelID, ]
    dBugControl("printing params")
    dBugControl(params)
    print(system.time(runModel(subModelID)))
    if ("SECAD" %in% params$AdoptRunMod) {
      
      if (params$RunsOut == "On") {
        ModelType = params$ModelType
        ModelNum = params$Model
        Runtime = "SECAD"
        Batch = b
        Run = r
        TotalAdopts = sum(SECADadoptStatus_vec)
        tmpRunOuts <<- cbind(ModelType, ModelNum, Runtime, Batch, Run, subModelID, TotalAdopts)
        RunOuts <<- rbind(RunOuts, tmpRunOuts)
      }#------End of Run out check
      

    }#------End of SECAD check
    
    if (params$AdoptionsOut == "On") {
      #			Adoption output block
    }#------End of Adoption out check
    if (params$ErrorOut == "On") {
      #			Error output block
    }#------End of Error out check
  }#------End of runs
}#------End of batches

if (params$RunsOut == "On") {
  write.csv(RunOuts, file=sprintf("outputs/RunOuts_ModABM_%s_%s_job%s.csv", params$ModelType, params$Model, params$job), row.names = FALSE )
}

if (params$QuartersOut == "On") {
  write.csv(QuarterOuts, file=sprintf("outputs/QuarterOuts_ModABM_%s_%s_job%s.csv", params$ModelType, params$Model, params$job), row.names = FALSE )
}

if (params$FollowOnsOut == "On") {
    write.csv(FollowOnsOut, file=sprintf("outputs/FollowOnsOut_ModABM_%s_%s_job%s.csv", params$ModelType, params$Model, params$job), row.names = FALSE )
  }
  
print("All done. Goodnight.")
warnings()
#q()
