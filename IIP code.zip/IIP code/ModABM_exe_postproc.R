# Modular Solar ABM analysis file
# D. Cale Reeves
# UT Austin, Energy Systems Transformation Group
# Last edit: 10/01/2017
#
# 

args = commandArgs(TRUE)

#---------------#
# Run Parameters ---- change to run for the models you want to compare
#---------------#
agentCSVpath = "inputs/ATXAgents.csv" 
EmpQuarters = 22
CompareModelNumber <- c(100001, 100002, 100003, 100004, 100005, 100006, 100007, 100008,
			100009,100010, 100011, 100012, 100013, 100014) 
CompareDescription <- c("Baseline", "PHAMB", "PHAMB", "CELEB", "PTALK", "PTALK", "PTALK", "PTALK",
			"CHAMP", "CHAMP", "CHAMP", "CHAMP", "ECONOMIC", "ECONOMIC") 
CompareModelType <- c("Regular", "ParamBlast", "ParamBlast", "ParamBlast", "ParamBlast", "ParamBlast", "ParamBlast", "ParamBlast", 
			"ParamBlast", "ParamBlast", "ParamBlast", "ParamBlast", "ParamBlast", "ParamBlast") 
outDir = ("outputs")
runlogDir = ("runlogs")
ProcOutDir = ("processedOuts")



# if (!is.na(args[1])) {
# 		print("Additional CMD line args present")
# 		if (args[1] == "ParamMagnitude" ) {
# 				print("[PreRun]     ..........Parameter Magnitude argument set")
# 				CompareModelType = "ParamMagnitude"
# 				CompareModelNumber = args[2]
# 				CompareDescription = args[3]
# 
# 			} else {
# 				print("XXX!!!XXX[PreRun]     	There has been an error	with setting Parameter Sweep or Magnitude Values XXX!!!XXX")	
# 				print(sprintf("XXX!!!XXX[PreRun]     	Arg 2: %s; Arg 3: $%s; Arg 4: %s; Arg 5: %s", args[2], args[3], args[4], args[5]))
# 				q()
# 		}
# 	} else {
# 		cat("No Additional CMD line args present\n")
# }
# 
# #OutFile <- file(sprintf("180725_ProcessEndOuts_SECAD_%s_Out.txt", CompareModelNumber))
# #sink(OutFile, append=FALSE, type=c("output"))
# #sink(OutFile, append=FALSE, type=c("message"))
# 
# print(getwd())

#-------------------------#
# Import Libraries
#-------------------------#

print("[Anls]          Loading Libraries ...")

library(parallel)
#library(ggplot2)
library(lubridate)
library(igraph)
library(reshape2)
library(MASS)
#library(ggmap)
library(scales)

print("[Anls]          ... Libraries Loaded")

#---------------#
# Build empiricals from agents 
#---------------#

print(sprintf("[Anls]          Building empirical comparison from: %s for %d Quarters", agentCSVpath, EmpQuarters))
print("[Anls]          Reading Agent Empiricals")
agents <- read.csv(as.character(agentCSVpath))

print("[Anls]          Calculating Empiricals...")
agents <- agents[agents$AdoptDate != "", ]
agents$AdoptDate = as.Date(agents$AdoptDate, "%m/%d/%y")
agents <- agents[order(agents$AdoptDate), ]
agents$initialAdopter[agents$AdoptDate < as.Date("01/01/2008", "%m/%d/%Y")] = 1 #Set initial adopters to those that adopt before 2008
agents$adopter <- 1

agents$adoptyear <- year(agents$AdoptDate)
agents$adoptmonth <- month(agents$AdoptDate)
agents$adoptquarter <- quarter(agents$AdoptDate)
agents$adoptyearquart <- paste(agents$adoptyear, agents$adoptquarter, sep="")

quartagg <- aggregate(adopter ~ adoptyearquart, data=agents, sum)

sumInitAdopts <- sum(quartagg$adopter[quartagg$adoptyearquart < 20080])

quartagg <- quartagg[quartagg$adoptyearquart > 20080, ]

#sumInitAdopts
#quartagg

NewAdopts = c(sumInitAdopts, quartagg$adopter)

NewAdopts <- NewAdopts[0:EmpQuarters+1]



Empirics <- data.frame(Quarter = seq(0, EmpQuarters), NewAdopts = NewAdopts)



Empirics$CumulAdopts <- cumsum(Empirics$NewAdopts)

tmpCumul <- Empirics$CumulAdopts[1:length(Empirics$CumulAdopts)-1]
tmpNewAd <- Empirics$NewAdopts[2:length(Empirics$NewAdopts)]

#tmpCumul
#tmpNewAd

Empirics$EmpGrowRate <- c(0, tmpNewAd/tmpCumul)

Empirics$Model <- "Empirical"
#omit initial conditions (quarter 0)
Empirics <- Empirics[Empirics$Quarter != 0,]


# head(Empirics)
# tail(Empirics)

Empirical_Total_Adopts <- max(Empirics$CumulAdopts)
#Empirical_Total_Adopts <- 2709

print("[Anls]          ...Empiricals Calculated")
print(sprintf("[Anls]          ...Total Empirical Adoptions: %d", Empirical_Total_Adopts))



#---------------#
# Get compare models RunOuts
#---------------#

print("[Anls]          Reading Models to compare")


print(sprintf("[Anls]          Compare Models:%s, Model Descriptions: %s", CompareModelNumber, CompareDescription))

print("[Anls]          Finding Comparison Model Output files")

BatchRunLog <- data.frame()
for(i in 1:length(CompareModelNumber)) {
	Out_pattern = sprintf("RunOuts_ModABM_%s_%s_job", CompareModelType[i], CompareModelNumber[i])
	Outfiles = unlist(lapply(Out_pattern, function(x){list.files(path = outDir, pattern =x)}))
	for(j in 1:length(Outfiles)) {
		print(sprintf("[Anls]          Reading Model Run Output File:%s", Outfiles[j]))
		tmpRunLog <- read.csv(file = sprintf("%s/%s", outDir, Outfiles[j]))
		tmpRunLog$JobID <- j
		BatchRunLog <<- rbind(BatchRunLog, tmpRunLog)
	}	
}
BatchRunLog$uniqueRunID <- paste(BatchRunLog$ModelNum, BatchRunLog$JobID, BatchRunLog$subModelID, sep="-")

# head(BatchRunLog)
# tail(BatchRunLog)



#---------------#
# Get compare models FollowOnOuts
#---------------#

print("[Anls]          Reading Models to compare")


print(sprintf("[Anls]          Compare Models:%s, Model Descriptions: %s", CompareModelNumber, CompareDescription))

print("[Anls]          Finding Comparison Model Output files")

BatchFollowOnLog <- data.frame()
for(i in 2:(length(CompareModelNumber)-2)) {
  Out_pattern = sprintf("FollowOnsOut_ModABM_%s_%s_job", CompareModelType[i], CompareModelNumber[i])
  Outfiles = unlist(lapply(Out_pattern, function(x){list.files(path = outDir, pattern =x)}))
  for(j in 1:length(Outfiles)) {
    print(sprintf("[Anls]          Reading Model Run Output File:%s", Outfiles[j]))
    tmpFollowOnLog <- read.csv(file = sprintf("%s/%s", outDir, Outfiles[j]))
    tmpFollowOnLog$JobID <- j
    BatchFollowOnLog <<- rbind(BatchFollowOnLog, tmpFollowOnLog)
  }	
}
BatchFollowOnLog$uniqueRunID <- paste(BatchFollowOnLog$ModelNum, BatchFollowOnLog$JobID, BatchFollowOnLog$subModelID, sep="-")

BatchFollowOnLog <- subset(BatchFollowOnLog, select = c("FollowOns","uniqueRunID"))
  

# head(BatchFollowOnLog)
# tail(BatchFollowOnLog)



#---------------#
# Get compare models ParamLogs
#---------------#

print("[Anls]          Reading Model Parameter Logs")


print(sprintf("[Anls]          Compare ParamLogs:%s, Model Descriptions: %s", CompareModelNumber, CompareDescription))

print("[Anls]          Finding Comparison Model Parameter Logs files")

BatchParamLog <- data.frame()
for(i in 2:length(CompareModelNumber)) {
	Out_pattern = sprintf("ParamLog_ModABM_%s_%s_job", CompareModelType[i], CompareModelNumber[i])
	Outfiles = unlist(lapply(Out_pattern, function(x){list.files(path = runlogDir, pattern =x)}))
	for(j in 1:length(Outfiles)) {
		print(sprintf("[Anls]          Reading Model Parameter Log File:%s", Outfiles[j]))
		tmpParamLog <- read.csv(file = sprintf("%s/%s", runlogDir, Outfiles[j]))
		tmpParamLog$JobID <- j
		
		tmpParamLog$InterventionType <- CompareDescription[i]
		tmpParamLog$SeedSelection <- unlist(tmpParamLog[c(paste(CompareDescription[i], "howToChoose", sep="_"))])
		tmpParamLog$Training <- unlist(tmpParamLog[c(paste(CompareDescription[i], "Training", sep="_"))])				
		tmpParamLog$FollowOn_Rate <- unlist(tmpParamLog[c(paste(CompareDescription[i], "FollowOn_Rate", sep="_"))])
		tmpParamLog$howManySEEDS <- unlist(tmpParamLog[c(paste(CompareDescription[i], "howManySEEDS", sep="_"))])
		
		tmpParamLog <- subset(tmpParamLog, select = c("Model", "JobID", "subModelID", "InterventionType", "SeedSelection", "Training", "howManySEEDS","FollowOn_Rate"))

		
		BatchParamLog <<- rbind(BatchParamLog, tmpParamLog)
		
	}	
}
# 
# head(BatchParamLog)
# tail(BatchParamLog)


BatchParamLog$uniqueRunID <- paste(BatchParamLog$Model, BatchParamLog$JobID, BatchParamLog$subModelID, sep="-")

BatchParamLog <- subset(BatchParamLog, select = c("InterventionType", "SeedSelection", "Training", "howManySEEDS","FollowOn_Rate", "uniqueRunID"))

#---------------#
# Merge Parameter Logs to Run Outs
#---------------#

warnings()
# head(BatchRunLog)
# head(BatchFollowOnLog)
# head(BatchParamLog)

nrow(BatchRunLog)
nrow(BatchFollowOnLog)
nrow(BatchParamLog)


Run_Param_DF <- merge(BatchRunLog, BatchParamLog, by="uniqueRunID", all.x = TRUE)
Run_Param_DF <- merge(Run_Param_DF, BatchFollowOnLog, by="uniqueRunID", all.x = TRUE)
# nrow(Run_Param_DF)
# head(Run_Param_DF)
# tail(Run_Param_DF)
# 
# q()

Run_Param_DF$AdditionalAdopts <- Run_Param_DF$TotalAdopts - Empirical_Total_Adopts


head(Run_Param_DF)

nrow(Run_Param_DF)

write.csv(Run_Param_DF, file="processedOuts/181203_WOMpump_DCR.csv")

q()

 ModelType ModelNum Runtime Batch Run subModelID TotalAdopts JobID  uniqueRunID

































#---------------#
# Get agents
#---------------#
agents <- read.csv(file="inputs/ATXAgents.csv")

#---------------#
# Get Comparison End Outs
#---------------#

print("[Anls]          Reading Models to compare")


print(sprintf("[Anls]          Compare Models:%s, Model Descriptions: %s", CompareModelNumber, CompareDescription))


print("[Anls]          Finding Comparison Model EndState Output files")

PRadoption <- NULL
aveAttAct <- NULL
aveEconAct <- NULL

for(i in 1:length(CompareModelNumber)) {
	Out_pattern = sprintf("EndStateOuts_ModABM_%s_%s",CompareModelType[i],CompareModelNumber[i])
	Outfiles = unlist(lapply(Out_pattern, function(x){list.files(path = outDir, pattern =x)}))
        mclapply(seq(1,length(Outfiles)), function(j) {
		print(sprintf("[Anls]          Outfile %d of %d", j, length(Outfiles)))
		print(sprintf("[Anls]          Reading Model EndState Output File:%s", Outfiles[j]))
		
		
		tmpDF <- read.csv(file = sprintf("%s/%s", outDir, Outfiles[j]))
		tmpPRadoption <- as.data.frame(aggregate(data = tmpDF, adopter ~ agentID, FUN=mean))
		tmpPRadoption <- tmpPRadoption[order(tmpPRadoption$agentID),]
		
		tmpAttAct <- as.data.frame(aggregate(data = tmpDF, AttAct ~ agentID, FUN=mean))
		tmpAttAct <- tmpAttAct[order(tmpAttAct$agentID),]
		
		tmpEconAct <- as.data.frame(aggregate(data = tmpDF, EconAct ~ agentID, FUN=mean))
		tmpEconAct <- tmpEconAct[order(tmpEconAct$agentID),]

#		print(tmpDF)

		EndOutsPreProcess <- data.frame(agentID = agents$agentIndex, adopter=tmpPRadoption$adopter, AttAct=tmpAttAct$AttAct, EconAct=tmpEconAct$EconAct)
		save(EndOutsPreProcess, file=sprintf("processedOuts/preProcs/PreProcEndOuts_%s_%s_%d.Rdata", CompareDescription[i], as.character(CompareModelNumber[i]), j))

#		print(EndOutsPreProcess)


        }, mc.cores=48)
}

print("Process PreProcs Now")

for(i in 1:length(CompareModelNumber)) {
	Out_pattern = sprintf("PreProcEndOuts_%s_%s",CompareDescription[i], as.character(CompareModelNumber[i]))
	Outfiles = unlist(lapply(Out_pattern, function(x){list.files(path = PreProcDir, pattern =x)}))
	for(j in 1:length(Outfiles)) {
		print(sprintf("[Anls]          Outfile %d of %d", j, length(Outfiles)))
		print(sprintf("[Anls]          Reading Model EndState PreProc File:%s", Outfiles[j]))
		
		load(file=sprintf("%s/%s", PreProcDir, Outfiles[j]))

#		print(head(EndOutsPreProcess))
		PRadoption <<- cbind(PRadoption, EndOutsPreProcess$adopter)
		aveAttAct <<- cbind(aveAttAct, EndOutsPreProcess$AttAct)
		aveEconAct <<- cbind(aveEconAct, EndOutsPreProcess$EconAct)
	}	
}




print(head(PRadoption))
print(head(aveAttAct))
print(head(aveEconAct))

print("that was diagnostic")

#PRadoption <- as.data.frame(aggregate(data = tmpPRadoptionDF, adopter ~ agentID, FUN=mean))

meanPRadoption <- rowMeans(PRadoption)
meanAttAct <- rowMeans(aveAttAct)
meanEconAct <- rowMeans(aveEconAct)

SECADEndOuts <- data.frame(agentID = agents$agentIndex, PR_adoption = meanPRadoption, PR_AttAct = meanAttAct, PR_EconAct = meanEconAct)

SECADEndOuts$PR_nonAttAct <- 1 - SECADEndOuts$PR_AttAct

SECADEndOuts$PR_nonEconAct <- 1 - SECADEndOuts$PR_EconAct

SECADEndOuts$PR_nonAdopt <- 1 - SECADEndOuts$PR_adoption

#print(SECADEndOuts)

save(SECADEndOuts, file="ProcEndOuts_Regular_SECAD_100118.Rdata")
#, CompareModelType, CompareDescription, as.character(CompareModelNumber)))





q()







































################  ----- Break time


load(file=sprintf("inputs/ProcEndOuts_%s_%s.Rdata", CompareDescription, as.character(CompareModelNumber)))



ls()

str(SECADEndOuts)

range(SECADEndOuts$meanAttAct)

SECADEndOuts$PR_nonAttAct <- 1 - SECADEndOuts$meanAttAct


range(SECADEndOuts$meanEconAct)

SECADEndOuts$meanEconAct <- SECADEndOuts$meanEconAct

SECADEndOuts$PR_nonEconAct <- 1 - SECADEndOuts$meanEconAct


range(SECADEndOuts$meanPRadoption)

SECADEndOuts$meanPRadoption <- SECADEndOuts$meanPRadoption

SECADEndOuts$PR_nonAdopt <- 1 - SECADEndOuts$meanPRadoption


head(SECADEndOuts)



hist(SECADEndOuts$PR_nonAttAct)


SECADEndOuts$AttProspectValue <- SECADEndOuts$PR_nonAttAct * SECADEndOuts$meanEconAct

SECADEndOuts$EconProspectValue <- SECADEndOuts$PR_nonEconAct * SECADEndOuts$meanAttAct

hist(SECADEndOuts$AttProspectValue)

range(SECADEndOuts$AttProspectValue)

hist(SECADEndOuts$EconProspectValue)

range(SECADEndOuts$EconProspectValue)


agents$AttProspectValue <- SECADEndOuts$AttProspectValue
agents$EconProspectValue <- SECADEndOuts$EconProspectValue

LongRange = c(-98, -97.56)
LatRange = c(30.09, 30.47)

# str(LongRange)
# print("that was str longrange")

# Calculate the 2d density estimate over the common range


N_dens <- 200

LongIncrement <- (max(LongRange)-min(LongRange))/N_dens
LatIncrement <- (max(LatRange)-min(LatRange))/N_dens
# LongIncrement
# LatIncrement


#   with(quakes, {
#       d <- kde3d(long, lat, -depth, n = 40)
#       contour3d(d$d, exp(-12), d$x/22, d$y/28, d$z/640,
#                 color = "green", color2 = "gray", scale=FALSE,
#                 engine = "standard")
#   })
#   
#   q()

kde2d.weighted <- function (x, y, w, h, n = n, lims = c(range(x), range(y))) {
  nx <- length(x)
  if (length(y) != nx) 
      stop("data vectors must be the same length")
  gx <- seq(lims[1], lims[2], length = n) # gridpoints x
  gy <- seq(lims[3], lims[4], length = n) # gridpoints y
  if (missing(h)) 
    h <- c(bandwidth.nrd(x), bandwidth.nrd(y));
  if (missing(w)) 
    w <- numeric(nx)+1;
  h <- h/4
  ax <- outer(gx, x, "-")/h[1] # distance of each point to each grid point in x-direction
  ay <- outer(gy, y, "-")/h[2] # distance of each point to each grid point in y-direction
  z <- (matrix(rep(w,n), nrow=n, ncol=nx, byrow=TRUE)*matrix(dnorm(ax), n, nx)) %*% t(matrix(dnorm(ay), n, nx))/(sum(w) * h[1] * h[2]) # z is the density
  return(list(x = gx, y = gy, z = z))
}




AttProspectValue100 = kde2d.weighted(agents$WGSlong, agents$WGSlat, agents$AttProspectValue, h=c(5*LongIncrement, 5*LatIncrement) , lims=c(LongRange, LatRange), n=N_dens)

AttProspectValue100.m = melt(AttProspectValue100$z, id.var=rownames(AttProspectValue100))
names(AttProspectValue100.m) = c("Long","Lat","z")

AttProspectValue100.m$adjLong <- (AttProspectValue100.m$Long * LongIncrement) + min(LongRange)
AttProspectValue100.m$adjLat<- (AttProspectValue100.m$Lat * LatIncrement) + min(LatRange)
AttProspectValue100.m$adjz <- rescale(AttProspectValue100.m$z, to = c(0,1))
AttProspectValue100.m$STDadjz <- scale(AttProspectValue100.m$z)
print(sprintf("Attitudinal Prospect Value density calculated for a %d square grid", N_dens))




EconProspectValue100 = kde2d.weighted(agents$WGSlong, agents$WGSlat, agents$EconProspectValue, h=c(5*LongIncrement, 5*LatIncrement) , lims=c(LongRange, LatRange), n=N_dens)

EconProspectValue100.m = melt(EconProspectValue100$z, id.var=rownames(EconProspectValue100))
names(EconProspectValue100.m) = c("Long","Lat","z")

EconProspectValue100.m$adjLong <- (EconProspectValue100.m$Long * LongIncrement) + min(LongRange)
EconProspectValue100.m$adjLat<- (EconProspectValue100.m$Lat * LatIncrement) + min(LatRange)
EconProspectValue100.m$adjz <- rescale(EconProspectValue100.m$z, to = c(0,1))
EconProspectValue100.m$STDadjz <- scale(EconProspectValue100.m$z)
print(sprintf("Economic Prospect Value density calculated for a %d square grid", N_dens))




AustinMap <- ggmap(get_map(location = c(lon = -97.78, lat = 30.28), zoom = 11)) 




AttProspectValuePlotNameraw = "AttProspectValuePlot_SECADraw"

AttProspectValuePlotraw <- AustinMap +
	geom_point(data = agents, aes(x = WGSlong, y = WGSlat, color=AttProspectValue, alpha=AttProspectValue), shape = 16, size = 0.6) + 
	geom_tile(data = agents, aes(x = WGSlong, y = WGSlat, z=AttProspectValue)) +
#	geom_contour(data=AttProspectValue100.m, aes(x = adjLong, y  = adjLat, z=z)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
 	scale_color_gradient(low="green", high="red", name="Attitudinal\nProspect\nProbability") +
  	coord_cartesian(xlim=LongRange, ylim=LatRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Longitude") +
	scale_y_continuous(name="Latitude") +
	theme_bw()
ggsave(paste0(AttProspectValuePlotNameraw, ".eps"), AttProspectValuePlotraw, path = "graphics/", width = 12, height = 10, units = 'in',  device=cairo_ps)
ggsave(paste0(AttProspectValuePlotNameraw, ".png"), AttProspectValuePlotraw, path = "graphics/", width = 12, height = 10, units = 'in', dpi=300)



AttProspectValuePlotName = "AttProspectValuePlot_SECADrawdens"

AttProspectValuePlot <- AustinMap +
	geom_point(data = agents, aes(x = WGSlong, y = WGSlat), shape = 16, size = 0.6) + 
	geom_tile(data=AttProspectValue100.m, aes(x = adjLong, y  = adjLat, z=z, fill=z, alpha=z)) +
	geom_contour(data=AttProspectValue100.m, aes(x = adjLong, y  = adjLat, z=z)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
 	scale_fill_gradient(low="green", high="red", name="Attitudinal\nProspect\nValue\nDensity") +
  	coord_cartesian(xlim=LongRange, ylim=LatRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Longitude") +
	scale_y_continuous(name="Latitude") +
	theme_bw()

ggsave(paste0(AttProspectValuePlotName, ".eps"), AttProspectValuePlot, path = "graphics/", width = 12, height = 10, units = 'in',  device=cairo_ps)
ggsave(paste0(AttProspectValuePlotName, ".png"), AttProspectValuePlot, path = "graphics/", width = 12, height = 10, units = 'in', dpi=300)


AttProspectValuePlotNameSTD = "AttProspectValuePlot_SECADSTDdens"

AttProspectValuePlotSTD <- AustinMap +
	geom_point(data = agents, aes(x = WGSlong, y = WGSlat), shape = 16, size = 0.6) + 
	geom_tile(data=AttProspectValue100.m, aes(x = adjLong, y  = adjLat, z=STDadjz, fill=STDadjz, alpha=STDadjz)) +
	geom_contour(data=AttProspectValue100.m, aes(x = adjLong, y  = adjLat, z=STDadjz)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
 	scale_fill_gradient(low="green", high="red", name="Attitudinal\nProspect\nValue\nDensity") +
  	coord_cartesian(xlim=LongRange, ylim=LatRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Longitude") +
	scale_y_continuous(name="Latitude") +
	theme_bw()

ggsave(paste0(AttProspectValuePlotNameSTD, ".eps"), AttProspectValuePlotSTD, path = "graphics/", width = 12, height = 10, units = 'in',  device=cairo_ps)
ggsave(paste0(AttProspectValuePlotNameSTD, ".png"), AttProspectValuePlotSTD, path = "graphics/", width = 12, height = 10, units = 'in', dpi=300)


quantile(AttProspectValue100.m$STDadjz, 0.99)

AttProspectValue100.m.ntile <- AttProspectValue100.m[AttProspectValue100.m$STDadjz > quantile(AttProspectValue100.m$STDadjz, 0.99), ]


AttProspectValuePlotNameSTDntile = "AttProspectValuePlot_SECADSTDntile"

AttProspectValuePlotSTDntile <- AustinMap +
	geom_point(data = agents, aes(x = WGSlong, y = WGSlat), shape = 16, size = 0.6, alpha=0.3) + 
	geom_tile(data=AttProspectValue100.m.ntile, aes(x = adjLong, y  = adjLat, fill="blue")) +
#	geom_contour(data=ProspectValue100.m.ntile, aes(x = adjLong, y  = adjLat, z=STDadjz)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
# 	scale_fill_gradient(low="green", high="red", name="Prospect\nValue\nDensity") +
  	coord_cartesian(xlim=LongRange, ylim=LatRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Longitude") +
	scale_y_continuous(name="Latitude") +
	theme_bw()

ggsave(paste0(AttProspectValuePlotNameSTDntile, ".eps"), AttProspectValuePlotSTDntile, path = "graphics/", width = 12, height = 10, units = 'in',  device=cairo_ps)
ggsave(paste0(AttProspectValuePlotNameSTDntile, ".png"), AttProspectValuePlotSTDntile, path = "graphics/", width = 12, height = 10, units = 'in', dpi=300)



EconProspectValuePlotNameraw = "EconProspectValuePlot_SECADraw"

EconProspectValuePlotraw <- AustinMap +
	geom_point(data = agents, aes(x = WGSlong, y = WGSlat, color=EconProspectValue, alpha=EconProspectValue), shape = 16, size = 0.6) + 
	geom_tile(data = agents, aes(x = WGSlong, y = WGSlat, z=EconProspectValue)) +
#	geom_contour(data=AttProspectValue100.m, aes(x = adjLong, y  = adjLat, z=z)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
 	scale_color_gradient(low="green", high="red", name="Economic\nProspect\nProbability") +
  	coord_cartesian(xlim=LongRange, ylim=LatRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Longitude") +
	scale_y_continuous(name="Latitude") +
	theme_bw()

ggsave(paste0(EconProspectValuePlotNameraw, ".eps"), EconProspectValuePlotraw, path = "graphics/", width = 12, height = 10, units = 'in',  device=cairo_ps)
ggsave(paste0(EconProspectValuePlotNameraw, ".png"), EconProspectValuePlotraw, path = "graphics/", width = 12, height = 10, units = 'in', dpi=300)




EconProspectValuePlotName = "EconProspectValuePlot_SECADrawdens"

EconProspectValuePlot <- AustinMap +
	geom_point(data = agents, aes(x = WGSlong, y = WGSlat), shape = 16, size = 0.6) + 
	geom_tile(data=EconProspectValue100.m, aes(x = adjLong, y  = adjLat, z=z, fill=z, alpha=z)) +
	geom_contour(data=EconProspectValue100.m, aes(x = adjLong, y  = adjLat, z=z)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
 	scale_fill_gradient(low="green", high="red", name="Economic\nProspect\nValue\nDensity") +
  	coord_cartesian(xlim=LongRange, ylim=LatRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Longitude") +
	scale_y_continuous(name="Latitude") +
	theme_bw()

ggsave(paste0(EconProspectValuePlotName, ".eps"), EconProspectValuePlot, path = "graphics/", width = 12, height = 10, units = 'in',  device=cairo_ps)
ggsave(paste0(EconProspectValuePlotName, ".png"), EconProspectValuePlot, path = "graphics/", width = 12, height = 10, units = 'in', dpi=300)

EconProspectValuePlotNameSTD = "EconProspectValuePlot_SECADSTDdens"

EconProspectValuePlotSTD <- AustinMap +
	geom_point(data = agents, aes(x = WGSlong, y = WGSlat), shape = 16, size = 0.6) + 
	geom_tile(data=EconProspectValue100.m, aes(x = adjLong, y  = adjLat, z=STDadjz, fill=STDadjz, alpha=STDadjz)) +
	geom_contour(data=EconProspectValue100.m, aes(x = adjLong, y  = adjLat, z=STDadjz)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
 	scale_fill_gradient(low="green", high="red", name="Economic\nProspect\nValue\nDensity") +
  	coord_cartesian(xlim=LongRange, ylim=LatRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Longitude") +
	scale_y_continuous(name="Latitude") +
	theme_bw()

ggsave(paste0(EconProspectValuePlotNameSTD, ".eps"), EconProspectValuePlotSTD, path = "graphics/", width = 12, height = 10, units = 'in',  device=cairo_ps)
ggsave(paste0(EconProspectValuePlotNameSTD, ".png"), EconProspectValuePlotSTD, path = "graphics/", width = 12, height = 10, units = 'in', dpi=300)




quantile(EconProspectValue100.m$STDadjz, 0.99)

EconProspectValue100.m.ntile <- EconProspectValue100.m[EconProspectValue100.m$STDadjz > quantile(EconProspectValue100.m$STDadjz, 0.99), ]


EconProspectValuePlotNameSTDntile = "EconProspectValuePlot_SECADSTDntile"

EconProspectValuePlotSTDntile <- AustinMap +
	geom_point(data = agents, aes(x = WGSlong, y = WGSlat), shape = 16, size = 0.6, alpha=0.3) + 
	geom_tile(data=EconProspectValue100.m.ntile, aes(x = adjLong, y  = adjLat, fill="blue")) +
#	geom_contour(data=ProspectValue100.m.ntile, aes(x = adjLong, y  = adjLat, z=STDadjz)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
# 	scale_fill_gradient(low="green", high="red", name="Prospect\nValue\nDensity") +
  	coord_cartesian(xlim=LongRange, ylim=LatRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Longitude") +
	scale_y_continuous(name="Latitude") +
	theme_bw()

ggsave(paste0(EconProspectValuePlotNameSTDntile, ".eps"), EconProspectValuePlotSTDntile, path = "graphics/", width = 12, height = 10, units = 'in',  device=cairo_ps)
ggsave(paste0(EconProspectValuePlotNameSTDntile, ".png"), EconProspectValuePlotSTDntile, path = "graphics/", width = 12, height = 10, units = 'in', dpi=300)


q()
