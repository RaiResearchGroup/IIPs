# Modular Solar ABM Core Runtime Modules
# D. Cale Reeves
# UT Austin, Energy Systems Transformation Group
# Last edit: 05/22/2017
#
# 

SECADRuntimeStaging <- function () {
  print("[Core]          Staging Runtime with SECAD module") 
  
  SECADEcon <<- read.csv(as.character(params$SECADEconData))
  
  SECADagentIndex_vec <<- as.numeric(agents$agentIndex)			# Also keep in in a vector
  SECADadoptStatus_vec <<- as.numeric(agents$Adopter)			# Also keep in in a vector
  SECADSIA_vec <<- as.numeric(agents$SIA) 				# Also keep in in a vector
  SECADU_vec <<- as.numeric(agents$U) 				# Also keep in in a vector
  SECADPBC_vec <<- as.numeric(params$SECAD_FIT_PBCscaler_a0 + (params$SECAD_FIT_PBCscaler_a1 * agents$PBC_raw) )				# Also keep in in a vector
  SECADAlter_vec <<- mapply(c, SECADLocals, SECADnonLocals)
  SECADAlter_vec[is.na(SECADLocals)] <<- SECADnonLocals[is.na(SECADLocals)]

  SECAD_seeds_vec <<- rep(0, length(SECADagentIndex_vec))			# Also keep in in a vector
  SECAD_followon_vec <<- rep(0, length(SECADagentIndex_vec))			# Also keep in in a vector


  dBugInit("any agents with no locals?")
  dBugInit(SECADagentIndex_vec[is.na(SECADLocals)])
  
  dBugInit("double check agents with no locals?")
  dBugInit(SECADAlter_vec[is.na(SECADLocals)]) 
  
  dBugInit(sprintf("SECADagentIndex_vec length: %d", length(SECADagentIndex_vec)))
  dBugInit(sprintf("SECADadoptStatus_vec sum: %d", sum(SECADadoptStatus_vec)))
  dBugInit(sprintf("SECADSIA_vec mean: %f", mean(SECADSIA_vec)))
  dBugInit(sprintf("SECADU_vec mean: %f", mean(SECADU_vec)))
  dBugInit(sprintf("SECADPBC_vec mean: %f", mean(SECADPBC_vec)))
  dBugInit(head(SECADAlter_vec))


 
  
  print("[Core]          SECAD Runtime Staging finished")
  
}#------End of SECADRuntimeStaging function


SECADupdate <- function (subModelID, q) {
  
  #####------------------------#
  ### Check for CELEB  
  #####------------------------#	
  
  dBugIntv(sprintf("q is: %d", q))
  dBugIntv("This is params$CELEB_doQuarters_vec")
  dBugIntv(params$CELEB_doQuarters_vec)
  
  dBugIntv("This is str(params$CELEB_doQuarters_vec)")
  dBugIntv(str(params$CELEB_doQuarters_vec))
  
  if (q %in% as.list(strsplit(as.character(params$CELEB_doQuarters_vec), ";"))[[1]]) {
    print("doing CELEB update")
    
    CELEBinterventions_vec <<- c()
    
    for (i in 1:params$CELEB_howManySEEDS) {   
      print("doing CELEB number")
      print(i)
      
    if (params$CELEB_howToChoose == "Random") {
      print("doing Random seeding")
      
     
      CELEBinterventions_x <<- sample(SECADagentIndex_vec, size = round(params$CELEB_FollowOn_Rate*length(SECADagentIndex_vec)), replace = FALSE)
      
      dBugIntv("These are (head) the followons getting updated - in order")
      dBugIntv(head(CELEBinterventions_x[order(CELEBinterventions_x)]))
      
      SECAD_followon_vec[CELEBinterventions_x] <<- 1
      dBugIntv("Tracking follow-ons")
      dBugIntv(SECAD_followon_vec[1:30])
      
      CELEBinterventions_vec <<- c(CELEBinterventions_x,CELEBinterventions_vec)
      

    } else if (params$CELEB_howToChoose == "HighK") {
      
      print("doing HighK seeding")
      K <- lengths(SECADAlter_vec)
      K_dataframe <- data.frame(SECADagentIndex_vec,K)
      K_vector <- as.vector(K_dataframe)
      col_headings <- c("index","K")
      names(K_vector) <- col_headings
      
      CELEBHIGHK <- head(K_vector[order(K_vector$K,sample(K_vector$index), decreasing = TRUE),],round(params$CELEB_FollowOn_Rate*length(SECADagentIndex_vec)))
      
      CELEBinterventions_x <<- as.vector(CELEBHIGHK$index)
      
      CELEBinterventions_vec <<- c(CELEBinterventions_x,CELEBinterventions_vec)
    }
      
      FollowOns_vec <<- CELEBinterventions_x
     
      if (params$CELEB_RA == "Static") {
        
        dBugIntv("This is pre intervention SIA: SECADSIA_vec[CELEBinterventions_x]")
        dBugIntv(SECADSIA_vec[CELEBinterventions_x])
        
        SECADSIA_vec[CELEBinterventions_vec & SECADSIA_vec < 0.6] <<- 0.6
        
        dBugIntv("This is post intervention SIA: SECADSIA_vec[CELEBinterventions_x]")
        dBugIntv(SECADSIA_vec[CELEBinterventions_vec])
      }   
      
      else if (params$CELEB_RA == "Relative Agreement") {
        
        dBugIntv("Creating Celeb - Matthew McConaughey")
        
        CelebMM_SIA <<- runif(1,params$SECAD_FIT_siaThresh,1)
        CelebMM_U <<- 1-abs(CelebMM_SIA)
        
        dBugIntv("THis is Matthew McConaughey's SIA")
        dBugIntv(CelebMM_SIA)
        
        dBugIntv("THis is Matthew McConaughey's U")
        dBugIntv(CelebMM_U) 
        
        Do_CELEB_Relative_Agreement <- function (i, j) {
          dBugIntv(print(sprintf("The follow-on (ego) %d that knows a celeb will contact celebrity number %d",j,i)) )
          
          priorSIA.j = SECADSIA_vec[j] 					# Attitude of agent j (target)
          priorU.j = SECADU_vec[j] 						# Uncertainty of agent j (target)
          
          dBugIntv(sprintf("Relative_Agreement on Agent: %d", j))
          
          dBugIntv(sprintf("Reltive_Agreement Prior sia: %f for agent: %d", priorSIA.j, j))
          dBugIntv(sprintf("Reltive_Agreement Prior U: %f for agent: %d", priorU.j, j))
          
          #connectIndices = unlist(SECADAlter_vec[agentID])
          
          #iInd = sample(connectIndices, 1) 	# Random connection index within agent i's connections
          
          dBugIntv(sprintf("RA Agent: %d interact w/ Target agent: %d", j, i))
          
          priorSIA.i = CelebMM_SIA 				# Attitude of agent i (connection)
          priorU.i = CelebMM_U					# Uncertainty of agent i (connection)
          
          dBugIntv(sprintf("Reltive_Agreement Prior sia: %f for Target agent: %d", priorSIA.i, i))
          dBugIntv(sprintf("Reltive_Agreement Prior U: %f for Target agent: %d", priorU.i, i))
          
          # Relative_Agreement algorithm: Deffuant et. al  http://jasss.soc.surrey.ac.uk/5/4/1.html
          overlap = (min((priorSIA.i + priorU.i),(priorSIA.j + priorU.j)) - max((priorSIA.i - priorU.i), (priorSIA.j - priorU.j)))
          
          dBugIntv(sprintf("Reltive_Agreement Overlap: %f", overlap))
          
          nonOverlap = 2 * priorU.i - overlap
          totAgreement = overlap - nonOverlap
          relAgreement = (2 * totAgreement) / (2 * priorU.i)
          
          # Check if overlap is greater than uncertainty of the influencing agent (priorU.i)
          if (overlap > priorU.i){
            #		print("Overlap was greater than uncertainty. Updating...")
            # Update target agent opinion and uncertainty
            priorSIA.j = priorSIA.j + params$SECAD_FIT_mu * relAgreement * (priorSIA.i - priorSIA.j)
            priorU.j = priorU.j + params$SECAD_FIT_mu * relAgreement * (priorU.i - priorU.j)
            
            
            SECADSIA_vec[j] <<- priorSIA.j
            SECADU_vec[j] <<- priorU.j
            
            #		print(sprintf("Old attitude: %s... New attitude: %s",priorSIA.j, priorSIA.j))
            #		print(sprintf("Old uncertainty: %s... New uncertainty: %s",priorU.j, priorU.j))
          }
          dBugIntv(sprintf("Reltive_Agreement Updated Prior sia: %f for agent: %d", priorSIA.j, j))
          dBugIntv(sprintf("Reltive_Agreement Updated Prior U: %f for agent: %d", priorU.j, j))
          
          
        }
        
        sapply(CELEBinterventions_x, function (j) Do_CELEB_Relative_Agreement(i, j))
        
        
        
        

      }    
      
    } #end of generating celeb intervention vec
    
    dBugIntv("These is the number of CELEB follow ons")
    dBugIntv(length(CELEBinterventions_vec))
    
    dBugIntv("These are the CELEB follow ons")
    dBugIntv(CELEBinterventions_vec)
    
    dBugIntv("This is post intervention SIA: SECADSIA_vec[CELEBinterventions_vec]")
    dBugIntv(SECADSIA_vec[CELEBinterventions_vec])
  
    
    # This is the code for generating the follow ons output file 
    
    if (params$FollowOnsOut == "On") {
      ModelType = params$ModelType
      ModelNum = params$Model
      Runtime = "SECAD"
      Batch = b
      Run = r
      Quarter = q
      TotalAdopts = sum(SECADadoptStatus_vec)
      FollowOns = length(FollowOns_vec)
      FO_Efficiency = TotalAdopts/FollowOns
      tmpFollowOnsOut <<- cbind(ModelType, ModelNum, Runtime, Batch, Run, Quarter, subModelID, TotalAdopts, FollowOns, FO_Efficiency)
      FollowOnsOut <<- rbind(FollowOnsOut, tmpFollowOnsOut)
    }   
    
    
  }
  
  else {
    print("NO CELEB update")
  }######    --------     END of Check for CELEB
  
  
  #####------------------------#
  ### Check for CHAMP 
  #####------------------------#	
  
  dBugIntv(sprintf("q is: %d", q))
  dBugIntv("This is params$CHAMP_doQuarters_vec")
  dBugIntv(params$CHAMP_doQuarters_vec)
  
  dBugIntv("This is str(params$CHAMP_doQuarters_vec)")
  dBugIntv(str(params$CHAMP_doQuarters_vec))
  
if (q %in% as.list(strsplit(as.character(params$CHAMP_doQuarters_vec), ";"))[[1]]) {
      print("doing CHAMP update")	
    # - create champs
    if (params$CHAMP_howtochoose == "Random") {
      
      CHAMPinterventions_vec <<- sample(SECADagentIndex_vec[SECADSIA_vec >= params$SECAD_FIT_siaThresh], size = params$CHAMP_howManySEEDS, replace = FALSE)
      
      dBugIntv("This is CHAMPinterventions_vec")
      dBugIntv(CHAMPinterventions_vec)
      
      dBugIntv("This is SIA of CHAMPinterventions_vec")
      dBugIntv(SECADSIA_vec[CHAMPinterventions_vec])
      
      dBugIntv("This is U of CHAMPinterventions_vec")
      dBugIntv(SECADU_vec[CHAMPinterventions_vec])
      
    } else if (params$CHAMP_howtochoose == "HighK") {
      
      CHAMP_pool <<- SECADagentIndex_vec[SECADSIA_vec >= params$SECAD_FIT_siaThresh] #this is all the agents that meet the CHAMP sia threshold, we will then pick the agents with Highest K of this pool 
      
      print("doing HighK seeding")
      K <<- lengths(SECADAlter_vec)
      K_dataframe <- data.frame(CHAMP_pool,K[CHAMP_pool])
      K_vector <<- as.vector(K_dataframe)
      col_headings <- c("index","K")
      names(K_vector) <- col_headings
      
      
      
      CHAMPHIGHK <<- head(K_vector[order(K_vector$K,sample(K_vector$index), decreasing = TRUE),],params$CHAMP_howManySEEDS)
      
      
      CHAMPinterventions_vec <<- as.vector(CHAMPHIGHK$index)
      
      dBugIntv("This is CHAMPinterventions_vec")
      dBugIntv(CHAMPinterventions_vec)
      
      dBugIntv("This is SIA of CHAMPinterventions_vec")
      dBugIntv(SECADSIA_vec[CHAMPinterventions_vec])
      
      dBugIntv("This is U of CHAMPinterventions_vec")
      dBugIntv(SECADU_vec[CHAMPinterventions_vec])
      
    }
  
    if (params$CHAMP_Training == "On") {
    
    print("CHAMP Training is On")
    
      sapply(CHAMPinterventions_vec, function(i) {
        SECADSIA_vec[i] <<- SECADSIA_vec[i] + 0.5*(1-SECADSIA_vec[i])
        SECADU_vec[i] <<- 1-abs(SECADSIA_vec[i])
      })
    
      dBugIntv("This is new SIA of CHAMPinterventions_vec after training")
      dBugIntv(SECADSIA_vec[CHAMPinterventions_vec])
  
      dBugIntv("This is new U of CHAMPinterventions_vec")
      dBugIntv(SECADU_vec[CHAMPinterventions_vec])
    
    
    }
    else {
      print("CHAMP Training is Off")
    }
    
  
    CHAMP_status_vec <<- rep(0, length(SECADadoptStatus_vec))
    
    dBugIntv("CHAMP_status_vec check")
    dBugIntv(head(CHAMP_status_vec))
    
    sapply(CHAMPinterventions_vec, function(i) {
      CHAMP_status_vec[i] <<- 1
    })
    
    
    dBugIntv("this is number of champs to confirm")
    dBugIntv(sum(CHAMP_status_vec))
    
    
   
    CHAMP_FOLLOWONS_TOTAL <<- c()
    sapply(CHAMPinterventions_vec, function (i) {
      
      CHAMP_AWARE<<- unlist(SECADAlter_vec[i]) 
      
      
      dBugIntv("This is CHAMP doing the work")
      dBugIntv(i)
      
      dBugIntv("This is the CHAMPS Social Network")
      dBugIntv(CHAMP_AWARE)
      
      dBugIntv("This is str(CHAMP_AWARE)")
      dBugIntv(str(CHAMP_AWARE))
      
      CHAMP_followons <<- sample(CHAMP_AWARE, round(params$CHAMP_FollowOn_Rate*length(CHAMP_AWARE)), replace=FALSE)
      CHAMP_FOLLOWONS_TOTAL <<-c(CHAMP_FOLLOWONS_TOTAL,CHAMP_followons)
      
      FollowOns_vec <<- CHAMP_FOLLOWONS_TOTAL
      
      dBugIntv("This is the CHAMPS follow ons")
      dBugIntv(CHAMP_followons)
      
      
      if (params$CHAMP_RA =="Static"){
        dBugIntv("Setting SIA to activated")
        
        dBugIntv("This is SECADSIA_vec before update")
        dBugIntv(SECADSIA_vec[CHAMP_followons]) 
        
        SECADSIA_vec[CHAMP_followons] <- 0.6
        
        dBugIntv("This is SECADSIA_vec after update")
        dBugIntv(SECADSIA_vec[CHAMP_followons])
        
      } else if (params$CHAMP_RA =="Relative_Agreement") {
        
        Do_CHAMP_Relative_Agreement <- function (i, j) {
          print(sprintf("The agent (ego) %d that knows a champion will contact champion number %d",j,i)) 
          
          priorSIA.j = SECADSIA_vec[j] 					# Attitude of agent j (target)
          priorU.j = SECADU_vec[j] 						# Uncertainty of agent j (target)
          
          dBugIntv(sprintf("Relative_Agreement on Agent: %d", j))
          
          dBugIntv(sprintf("Reltive_Agreement Prior sia: %f for agent: %d", priorSIA.j, j))
          dBugIntv(sprintf("Reltive_Agreement Prior U: %f for agent: %d", priorU.j, j))
          
          #connectIndices = unlist(SECADAlter_vec[agentID])
          
          #iInd = sample(connectIndices, 1) 	# Random connection index within agent i's connections
          
          dBugIntv(sprintf("RA Agent: %d interact w/ Target agent: %d", j, i))
          
          priorSIA.i = SECADSIA_vec[i] 				# Attitude of agent i (connection)
          priorU.i = SECADU_vec[i]					# Uncertainty of agent i (connection)
          
          dBugIntv(sprintf("Reltive_Agreement Prior sia: %f for Target agent: %d", priorSIA.i, i))
          dBugIntv(sprintf("Reltive_Agreement Prior U: %f for Target agent: %d", priorU.i, i))
          
          # Relative_Agreement algorithm: Deffuant et. al  http://jasss.soc.surrey.ac.uk/5/4/1.html
          overlap = (min((priorSIA.i + priorU.i),(priorSIA.j + priorU.j)) - max((priorSIA.i - priorU.i), (priorSIA.j - priorU.j)))
          
          dBugIntv(sprintf("Reltive_Agreement Overlap: %f", overlap))
          
          nonOverlap = 2 * priorU.i - overlap
          totAgreement = overlap - nonOverlap
          relAgreement = (2 * totAgreement) / (2 * priorU.i)
          
          # Check if overlap is greater than uncertainty of the influencing agent (priorU.i)
          if (overlap > priorU.i){
            #		print("Overlap was greater than uncertainty. Updating...")
            # Update target agent opinion and uncertainty
            priorSIA.j = priorSIA.j + params$SECAD_FIT_mu * relAgreement * (priorSIA.i - priorSIA.j)
            priorU.j = priorU.j + params$SECAD_FIT_mu * relAgreement * (priorU.i - priorU.j)
            
            
            SECADSIA_vec[j] <<- priorSIA.j
            SECADU_vec[j] <<- priorU.j
            
            #		print(sprintf("Old attitude: %s... New attitude: %s",priorSIA.j, priorSIA.j))
            #		print(sprintf("Old uncertainty: %s... New uncertainty: %s",priorU.j, priorU.j))
          }
          dBugIntv(sprintf("Reltive_Agreement Updated Prior sia: %f for agent: %d", priorSIA.j, j))
          dBugIntv(sprintf("Reltive_Agreement Updated Prior U: %f for agent: %d", priorU.j, j))
          
          
        }
        
        sapply(CHAMP_followons, function (j) Do_CHAMP_Relative_Agreement(i, j))
        
      }
      
      
    })	  

      SECAD_followon_vec[CHAMP_followons] <<- 1
      dBugIntv("Tracking follow-ons")
      dBugIntv(SECAD_followon_vec[1:30])

      SECAD_seeds_vec[CHAMPinterventions_vec] <<- 1
      dBugIntv("Tracking follow-ons")
      dBugIntv(SECAD_seeds_vec[1:30])
  
    # This is the code for generating the follow ons output file 
    
    if (params$FollowOnsOut == "On") {
      ModelType = params$ModelType
      ModelNum = params$Model
      Runtime = "SECAD"
      Batch = b
      Run = r
      Quarter = q
      TotalAdopts = sum(SECADadoptStatus_vec)
      FollowOns = length(FollowOns_vec)
      FO_Efficiency = TotalAdopts/FollowOns
      tmpFollowOnsOut <<- cbind(ModelType, ModelNum, Runtime, Batch, Run, Quarter, subModelID, TotalAdopts, FollowOns, FO_Efficiency)
      FollowOnsOut <<- rbind(FollowOnsOut, tmpFollowOnsOut)
    }     
    
  }
  
  #####------------------------#
  ###  Finished with  CHAMP 
  #####------------------------#		
  
  
  
  #####------------------------#
  ### Check for PHAMB  
  #####------------------------#	
  
  dBugIntv(sprintf("q is: %d", q))
  dBugIntv("This is params$PHAMB_doQuarters_vec")
  dBugIntv(params$PHAMB_doQuarters_vec)
  
  dBugIntv("This is params$PHAMB_doQuarters_vec")
  dBugIntv(params$PHAMB_doQuarters_vec)
  
  dBugIntv("This is params$PHAMB_howToConnectAMB")
  dBugIntv(params$PHAMB_howToConnectAMB)
  
  dBugIntv("This is params$PHAMB_howManySEEDS")
  dBugIntv(params$PHAMB_howManySEEDS)
  
if (q %in% as.list(strsplit(as.character(params$PHAMB_doQuarters_vec), ";"))[[1]]) {
    print(sprintf("[Core]                    PHAMB Intervention active with Seeds:%d and Follow-On:%f",params$PHAMB_AMB_howMany, params$PHAMB_TargetparticipationRate))    	
    
    if (params$PHAMB_howToChooseAMB == "Random") {
      print("doing Random PHAMB update")
      
      PHAMB_AMB_vec <<- sample(SECADagentIndex_vec[SECADadoptStatus_vec == 1], size = params$PHAMB_howManySEEDS, replace = FALSE)
      
      dBugIntv("This is PHAMB_AMB_vec")
      dBugIntv(PHAMB_AMB_vec)
    }
    else if (params$PHAMB_howToChooseAMB == "HighK") {
      print("doing HighK PHAMB update")
      
      PHAMB_AMB_pool <<- SECADagentIndex_vec[SECADadoptStatus_vec == 1]  #this is the total pool of phone ambassadors
      
      K <<- lengths(SECADAlter_vec)
      K_dataframe <- data.frame(PHAMB_AMB_pool,K[PHAMB_AMB_pool])
      K_vector <<- as.vector(K_dataframe)
      col_headings <- c("index","K")
      names(K_vector) <- col_headings
      
      PHAMBHIGHK <<- head(K_vector[order(K_vector$K,sample(K_vector$index), decreasing = TRUE),],params$PHAMB_howManySEEDS)
      
      PHAMB_AMB_vec <<- as.vector(PHAMBHIGHK$index)
      
      dBugQuarter("This is PHAMB_AMB_vec")
      dBugIntv(PHAMB_AMB_vec)
    }
    
    PHAMB_not_activated_total_vec <- SECADagentIndex_vec[SECADSIA_vec <= params$SECAD_FIT_siaThresh & SECADadoptStatus_vec == 0]
  
    dBugIntv("This is the total number of agents who are not activated (sia < 0.6) and are not adopters")
    dBugIntv(length(PHAMB_not_activated_total_vec))
    
    dBugIntv("This should be the number of follow-ons")
    dBugIntv(round(params$PHAMB_FollowOn_Rate*length(PHAMB_not_activated_total_vec)))
    
    #this is the new method for determining the follow ons
    PHAMB_Temp_SIA_df <- data.frame(PHAMB_not_activated_total_vec,SECADSIA_vec[PHAMB_not_activated_total_vec])
    PHAMB_Temp_SIA_df_rank <- PHAMB_Temp_SIA_df[order(PHAMB_Temp_SIA_df$SECADSIA_vec.PHAMB_not_activated_total_vec.),]
    PHAMB_Temp_FO_vec <- PHAMB_Temp_SIA_df_rank$PHAMB_not_activated_total_vec
    PHAMB_Target_vec <<- tail(PHAMB_Temp_FO_vec, n = round(params$PHAMB_FollowOn_Rate*length(PHAMB_not_activated_total_vec)))

    FollowOns_vec <<- PHAMB_Target_vec
    
    dBugIntv("This is the number of follow-ons it should match number above")
    dBugIntv(length(FollowOns_vec))
    
    if (length(PHAMB_Target_vec > 0)) {
    
      dBugIntv("This is head(PHAMB_Target_vec)")
      dBugIntv(head(PHAMB_Target_vec))
      
      dBugIntv(head("This is head(SECADAlter_vec[PHAMB_Target_vec]) before adding edges"))
      dBugIntv(head(SECADAlter_vec[PHAMB_Target_vec]))
      
      SECADAlter_vec[PHAMB_Target_vec] <<- sapply(SECADAlter_vec[PHAMB_Target_vec], function (i) as.integer(unique(c(i, PHAMB_AMB_vec))))
      
      dBugIntv(head("This is head(SECADAlter_vec[PHAMB_Target_vec]) after adding edges"))
      dBugIntv(head(SECADAlter_vec[PHAMB_Target_vec]))
      
        
    
      

      
    } # # end of "if (length(PHAMB_Target_vec > 0))" check 
      
      SECAD_followon_vec[FollowOns_vec] <<- 1
      dBugIntv("Tracking follow-ons")
      dBugIntv(SECAD_followon_vec[1:30])

      SECAD_seeds_vec[PHAMB_AMB_vec] <<- 1
      dBugIntv("Tracking follow-ons")
      dBugIntv(SECAD_seeds_vec[1:30])
      
   # This is the code for calculating total follow ons output.
    
     if (params$FollowOnsOut == "On") {
      ModelType = params$ModelType
      ModelNum = params$Model
      Runtime = "SECAD"
      Batch = b
      Run = r
      Quarter = q
      TotalAdopts = sum(SECADadoptStatus_vec)
      FollowOns = length(FollowOns_vec)
      FO_Efficiency = TotalAdopts/FollowOns
      tmpFollowOnsOut <<- cbind(ModelType, ModelNum, Runtime, Batch, Run, Quarter, subModelID, TotalAdopts, FollowOns, FO_Efficiency)
      FollowOnsOut <<- rbind(FollowOnsOut, tmpFollowOnsOut)
    }  
    
  } else {
    print("NO PHAMB update")
  }  ######    --------     END of Check for PHAMB
	
	#####------------------------#
    ### Check for PTALK  
    #####------------------------#
    
    dBugIntv(sprintf("q is: %d", q))
    dBugIntv("This is params$PTALK_doQuarters_vec")
    dBugIntv(params$PTALK_doQuarters_vec)
    
if (q %in% as.list(strsplit(as.character(params$PTALK_doQuarters_vec), ";"))[[1]]) {
      
    	print("doing PTALK update")
      
      	dBugIntv(sprintf("q is: %d", q))
      	dBugIntv("This is params$PTALK_doQuarters_vec")
      	dBugIntv(params$PTALK_doQuarters_vec)
      
      	dBugIntv("This is str(params$PTALK_doQuarters_vec)")
      	dBugIntv(str(params$PTALK_doQuarters_vec))
      
      	Pat_pool_vec <<- SECADagentIndex_vec[SECADadoptStatus_vec == 1] # this is the pool of eligible pats to choose from
      	
      	dBugIntv("This is head Pat_pool_vec")
      	dBugIntv(head(Pat_pool_vec))
      	
      	dBugIntv("This is head adopt status == 1 ")
      	dBugIntv(head(SECADagentIndex_vec[SECADadoptStatus_vec == 1]))
      	
      	dBugIntv("This is length of pat pool vec ")
      	dBugIntv(length(Pat_pool_vec))
      	
      	dBugIntv("This is length of adopt status == 1 ")
      	dBugIntv(length(SECADagentIndex_vec[SECADadoptStatus_vec == 1]))
      	
      	
      	if (params$PTALK_howToChoose == "Random"){
      	  
      	  Pat_vec<<- sample(Pat_pool_vec,params$PTALK_howManySEEDS,replace = FALSE) 
      	  dBugIntv("This is Pat_vec")
      	  dBugIntv(Pat_vec)
      	}
      	
      	else if (params$PTALK_howToChoose == "HighK"){
      	 
      	   print("doing HighK for Pat seeding")
      	  K <- lengths(SECADAlter_vec)
      	  K_dataframe <- data.frame(SECADagentIndex_vec,K)
      	  K_vector <- as.vector(K_dataframe)
      	  col_headings <- c("index","K")
      	  names(K_vector) <- col_headings
      	  
      	  PATHIGHK <<- head(K_vector[order(K_vector$K,sample(K_vector$index), decreasing = TRUE),],params$PTALK_howManySEEDS) #problem here to discuss with CALE .... I imagine its an artefact of toy data... not enough adopters? 
      	  
      	  Pat_vec <<- as.vector(PATHIGHK$index)
      	  
      	  dBugIntv("This is Pat_vec")
      	  dBugIntv(Pat_vec)
      	}
        
      	# - this is PTALK training
      	if (params$PTALK_Training == "On") {
      	  
      	  print("PTALK Training is On")
      	  
      	  dBugIntv("This is prior SIA of Pat_vec before training")
      	  dBugIntv(SECADSIA_vec[Pat_vec])
      	  
      	  dBugIntv("This is prior U of Pat_vec before training")
      	  dBugIntv(SECADU_vec[Pat_vec])
      	  
      	  sapply(Pat_vec, function(i) {
      	    SECADSIA_vec[i] <<- SECADSIA_vec[i] + 0.5*(1-SECADSIA_vec[i])
      	    SECADU_vec[i] <<- 1-abs(SECADSIA_vec[i])
      	  })
      	  
      	  dBugIntv("This is new SIA of Pat_vec after training")
      	  dBugIntv(SECADSIA_vec[Pat_vec])
      	  
      	  dBugIntv("This is new U of Pat_vec after training")
      	  dBugIntv(SECADU_vec[Pat_vec])
      	  
      	}
      	else {
      	  print("PTALK Training is Off")
      	}
      	
      # - End of PTALK training	
        	 
      	PTALK_FOLLOWONS_TOTAL <<- c()	
        	 sapply(Pat_vec, function (i) {
        	  
        	    Pats_Neighbors_vec <<- unlist(neiDF$GeoNei[i])  
        	    dBugIntv("This is Pats_Neighbors_vec")
        	    dBugIntv(Pats_Neighbors_vec)
        	 
        	    dBugIntv("This is str(Pats_Neighbors_vec)")
        	    dBugIntv(str(Pats_Neighbors_vec))
        	 
        	    Pats_Target_vec <<- sample(Pats_Neighbors_vec, round(params$PTALK_FollowOn_Rate*length(Pats_Neighbors_vec)), replace=FALSE)
        	    dBugIntv("This is the Pat  doing the Targeting")
        	    dBugIntv(i)
        	 
        	    dBugIntv("This is Pats followons")
        	    dBugIntv(Pats_Target_vec)
        	    
        	    PTALK_FOLLOWONS_TOTAL <<-c(PTALK_FOLLOWONS_TOTAL,Pats_Target_vec)
        	    
        	    FollowOns_vec <<- PTALK_FOLLOWONS_TOTAL
        	    
        	    
        	    
        	 
        	     if (params$PTALK_howtoUpdate =="Static"){
        	        dBugIntv("Setting SIA to activated")
        	     
        	         dBugIntv("This is SECADSIA_vec before update")
        	         dBugIntv(SECADSIA_vec[Pats_Target_vec]) 
        	   
        	         SECADSIA_vec[Pats_Target_vec] <- 0.6
        	
        	         dBugIntv("This is SECADSIA_vec after update")
        	         dBugIntv(SECADSIA_vec[Pats_Target_vec])
      	     
          	    } else if (params$PTALK_howtoUpdate =="Relative_Agreement") {
        	   
        	            Do_Pat_Relative_Agreement <- function (i, j) {
        	             print(sprintf("The Pat %d will update with the target number %d", i, j)) 
        	            
        	            priorSIA.j = SECADSIA_vec[j] 					# Attitude of agent j (target)
        	            priorU.j = SECADU_vec[j] 						# Uncertainty of agent j (target)
        	            
        	            dBugIntv(sprintf("Relative_Agreement on Agent: %d", j))
        	            
        	            dBugIntv(sprintf("Reltive_Agreement Prior sia: %f for agent: %d", priorSIA.j, j))
        	            dBugIntv(sprintf("Reltive_Agreement Prior U: %f for agent: %d", priorU.j, j))
        	            
        	            #connectIndices = unlist(SECADAlter_vec[agentID])
        	            
        	           #iInd = sample(connectIndices, 1) 	# Random connection index within agent i's connections
        	            
        	            dBugIntv(sprintf("RA Agent: %d interact w/ Target agent: %d", j, i))
        	            
        	            priorSIA.i = SECADSIA_vec[i] 				# Attitude of agent i (connection)
        	            priorU.i = SECADU_vec[i]					# Uncertainty of agent i (connection)
        	            
        	            dBugIntv(sprintf("Reltive_Agreement Prior sia: %f for Target agent: %d", priorSIA.i, i))
        	            dBugIntv(sprintf("Reltive_Agreement Prior U: %f for Target agent: %d", priorU.i, i))
        	            
        	            # Relative_Agreement algorithm: Deffuant et. al  http://jasss.soc.surrey.ac.uk/5/4/1.html
        	            overlap = (min((priorSIA.i + priorU.i),(priorSIA.j + priorU.j)) - max((priorSIA.i - priorU.i), (priorSIA.j - priorU.j)))
        	            
        	            dBugIntv(sprintf("Reltive_Agreement Overlap: %f", overlap))
        	            
        	            nonOverlap = 2 * priorU.i - overlap
        	            totAgreement = overlap - nonOverlap
        	            relAgreement = (2 * totAgreement) / (2 * priorU.i)
        	            
        	            # Check if overlap is greater than uncertainty of the influencing agent (priorU.i)
        	            if (overlap > priorU.i){
        	              #		print("Overlap was greater than uncertainty. Updating...")
        	              # Update target agent opinion and uncertainty
        	              priorSIA.j = priorSIA.j + params$SECAD_FIT_mu * relAgreement * (priorSIA.i - priorSIA.j)
        	              priorU.j = priorU.j + params$SECAD_FIT_mu * relAgreement * (priorU.i - priorU.j)
        	              
        	              
        	              SECADSIA_vec[j] <<- priorSIA.j
        	              SECADU_vec[j] <<- priorU.j
        	              
        	              #		print(sprintf("Old attitude: %s... New attitude: %s",priorSIA.j, priorSIA.j))
        	              #		print(sprintf("Old uncertainty: %s... New uncertainty: %s",priorU.j, priorU.j))
        	            }
        	            dBugIntv(sprintf("Reltive_Agreement Updated Prior sia: %f for agent: %d", priorSIA.j, j))
        	            dBugIntv(sprintf("Reltive_Agreement Updated Prior U: %f for agent: %d", priorU.j, j))
        	            
        	            
        	          }
        	  
        	          sapply(Pats_Target_vec, function (j) Do_Pat_Relative_Agreement(i, j))
        	   
        	      }
        	 
      
        	  })	  
      
        	 # This is the code for generating the follow ons output file 
        	 
        	    SECAD_followon_vec[Pats_Target_vec] <<- 1
      			dBugIntv("Tracking follow-ons")
      			dBugIntv(SECAD_followon_vec[1:30])

      			SECAD_seeds_vec[Pat_vec] <<- 1
      			dBugIntv("Tracking follow-ons")
      			dBugIntv(SECAD_seeds_vec[1:30])
        	 
        	 if (params$FollowOnsOut == "On") {
        	   ModelType = params$ModelType
        	   ModelNum = params$Model
        	   Runtime = "SECAD"
        	   Batch = b
        	   Run = r
        	   Quarter = q
        	   TotalAdopts = sum(SECADadoptStatus_vec)
        	   FollowOns = length(FollowOns_vec)
        	   FO_Efficiency = TotalAdopts/FollowOns
        	   tmpFollowOnsOut <<- cbind(ModelType, ModelNum, Runtime, Batch, Run, Quarter, subModelID, TotalAdopts, FollowOns, FO_Efficiency)
        	   FollowOnsOut <<- rbind(FollowOnsOut, tmpFollowOnsOut)
        	 }     
        	 
        
      	
    }  ######    --------     END of Check for PTALK	

	
    ########Economic Intervention#############

    if (q %in% as.list(strsplit(as.character(params$ECONOMIC_doQuarters_vec), ";"))[[1]]) {
      print(sprintf("[Core]                    ECONOMIC Intervention active with Seeds:%d", params$ECONOMIC_howManySEEDS))    	
      
      
      if (params$ECONOMIC_howtochoose == "Random") {
          
          print("doing Random Economic seeding")
          ECONOMICinterventions_vec <<- sample(SECADagentIndex_vec[SECADadoptStatus_vec == 0], size = params$ECONOMIC_howManySEEDS, replace = FALSE)
        }
  
      else if (params$ECONOMIC_howtochoose == "HighK"){
        
          print("doing HighK Economic seeding")
        
          ECONOMICinterventions_pool <<- SECADagentIndex_vec[SECADadoptStatus_vec == 0]  #this is the total pool of phone ambassadors
        
          K <<- lengths(SECADAlter_vec)
          K_dataframe <- data.frame(ECONOMICinterventions_pool,K[ECONOMICinterventions_pool])
          K_vector <<- as.vector(K_dataframe)
          col_headings <- c("index","K")
          names(K_vector) <- col_headings
        
          EconomicHIGHK <<- head(K_vector[order(K_vector$K,sample(K_vector$index), decreasing = TRUE),],params$ECONOMIC_howManySEEDS)
        
          ECONOMICinterventions_vec <<- as.vector(EconomicHIGHK$index)
          
          }
          

      dBugIntv("This is ECONOMICinterventions_vec")
      dBugIntv(ECONOMICinterventions_vec)
      
      dBugIntv("This is the pre-intervention adopt status of the seeds - should be zero for all")
      dBugIntv(SECADadoptStatus_vec[ECONOMICinterventions_vec])
      
      SECADadoptStatus_vec[ECONOMICinterventions_vec] <<- 1
      
      dBugIntv("This is the post-intervention adopt status of the seeds - should be one for all")
      dBugIntv(SECADadoptStatus_vec[ECONOMICinterventions_vec])

      }
    ######## End of Economic Intervention#############

	#####------------------------#
	### Write Out Networks
	#####------------------------#	
    SocNet_pI = data.frame(agentIndex = SECADagentIndex_vec, FollowOn = SECAD_followon_vec, Seed = SECAD_seeds_vec)

	SocNet_pI$Alters = SECADAlter_vec
    save(SocNet_pI, file=sprintf("outputs/SocNet_postIntervention_ModABM_%s_%s_b%d_job%s.Rdata", params$ModelType, params$Model, b, params$job) )
	SocNet_pI <- NULL


    
	#####------------------------#
	### Economics related 
	#####------------------------#	
	getPP = function(q, elecPrice, rebate){
		#gen = 1361									# This AE's estimate of the number of kWh generated by a solar system per year
		gen = agents$radMEANft * .77 / 1000 / 6					# Assume 23% efficiency and scale to kWh and area units (NREL PV Watts)
			
		#gen = ad2$radMEANft * .73 / 1000 / 6				# This is for pbc/pp checking
		gen[which(is.na(gen))] = 1361 # AE Default to catch NA's
		aeRebateCoefficient = .9556					# AE does not give full STC rating credit to panels, but 95%

		dBugIntv(sprintf("q is: %d", q))
		dBugIntv(sprintf("num_agents is: %d", length(SECADagentIndex_vec)))
		dBugIntv(sprintf("SECADEcon$PriceLoess[q] is: %f", SECADEcon$PriceLoess[q]))
		dBugIntv(sprintf("SECADEcon$PriceSD[q] is: %f", SECADEcon$PriceSD[q]))

		systemPrice = rnorm(length(SECADagentIndex_vec), SECADEcon$PriceLoess[q], (SECADEcon$PriceSD[q] / 2))	# System price forcast
			#systemPrice = rnorm(nrow(ad2), dwLoess$Loess[tick], (dwLoess$SD[tick]/2))	 # This is for pbc/pp checking
			
			
		ppVec = (systemPrice - (rebate * params$SECADEconRebateCoefficient) - 
				((systemPrice-(rebate * params$SECADEconRebateCoefficient)) * 
				params$SECADEconfedITC)) * 1000 / (gen * elecPrice)						# Calculates the simple PP using AE's formula
		return(ppVec)																	
	}
	

	print(sprintf("[Core]          Updating Quarter %d environment", q))
	
	dBugIntv(sprintf("q is: %d", q))
	dBugIntv(sprintf("Elec_VOC is: %f", SECADEcon$Elec_VOC[q]))
	dBugIntv(sprintf("Rebate_d_w is: %f", SECADEcon$Rebate_d_w[q]))
	
	PP_vec = getPP(q, SECADEcon$Elec_VOC[q], SECADEcon$Rebate_d_w[q])			# Get payback periods. PBC is already defined in loadDat.r
	EconActiv_vec <<- SECADPBC_vec >= PP_vec
	
	
	for(s in 1:params$SECAD_FIT_steps) {
		print(sprintf("[Core]               SECAD step %d in quarter: %d", s, q))
		timecode = sprintf("%s%s%s", subModelID, q, s)
		print(sprintf ("[Core]                    Timecode: %s", timecode))
		
		#####------------------------#
		### Attitude related
		#####------------------------#	
		
		#------------------------#
		# Relative Agreement
		#------------------------#		
		# Allows households to interact, potentially exchanging attitudes depended on uncertainty, "charisma"	
		relativeAgreement = function(agentID, SECADSIA_vec, SECADU_vec, SECADadoptStatus_vec){
			priorSIA.j = SECADSIA_vec[agentID] 					# Attitude of agent i (target)
			priorU.j = SECADU_vec[agentID] 						# Uncertainty of agent i (target)

			dBugSubstep(sprintf("Relative agreement on Agent: %d", agentID))

			dBugSubstep(sprintf("RA Prior sia: %f for agent: %d", priorSIA.j, agentID))
			dBugSubstep(sprintf("RA Prior U: %f for agent: %d", priorU.j, agentID))
		
			connectIndices = unlist(SECADAlter_vec[agentID])
			
			dBugSubstep(sprintf("RA Agent: %d potential Target agents:", agentID))
			dBugSubstep(connectIndices)			
			
			iInd = sample(connectIndices, 1) 	# Random connection index within agent i's connections
			
			dBugSubstep(sprintf("RA Agent: %d interact w/ Target agent: %d", agentID, iInd))

			priorSIA.i = SECADSIA_vec[iInd] 				# Attitude of agent j (connection)
			priorU.i = SECADU_vec[iInd]					# Uncertainty of agent i (target)

			dBugSubstep(sprintf("RA Prior sia: %f for Target agent: %d", priorSIA.i, iInd))
			dBugSubstep(sprintf("RA Prior U: %f for Target agent: %d", priorU.i, iInd))

			# Relative agreement algorithm: Deffuant et. al  http://jasss.soc.surrey.ac.uk/5/4/1.html
			overlap = (min((priorSIA.i + priorU.i),(priorSIA.j + priorU.j)) - max((priorSIA.i - priorU.i), (priorSIA.j - priorU.j)))
			
			dBugSubstep(sprintf("RA Overlap: %f", overlap))
			
			nonOverlap = 2 * priorU.i - overlap
			totAgreement = overlap - nonOverlap
			relAgreement = (2 * totAgreement) / (2 * priorU.i)
		
			# Check if overlap is greater than uncertainty of the influencing agent (priorU.i)
			if (overlap > priorU.i){
				#		print("Overlap was greater than uncertainty. Updating...")
				# Update target agent opinion and uncertainty
				priorSIA.j = priorSIA.j + params$SECAD_FIT_mu * relAgreement * (priorSIA.i - priorSIA.j)
				priorU.j = priorU.j + params$SECAD_FIT_mu * relAgreement * (priorU.i - priorU.j)	
				#		print(sprintf("Old attitude: %s... New attitude: %s",priorSIA.j, priorSIA.j))
				#		print(sprintf("Old uncertainty: %s... New uncertainty: %s",priorU.j, priorU.j))
			}
		dBugSubstep(sprintf("RA Updated Prior sia: %f for agent: %d", priorSIA.j, agentID))
		dBugSubstep(sprintf("RA Updated Prior U: %f for agent: %d", priorU.j, agentID))
		return(c(priorSIA.j, priorU.j))
	}
	
	
	
		#------------------------#
		# Adopt Check function
		#------------------------#		
		# Function runs agents through through the adoption function
		# Depends only on SIA, ECON module and current adoption status	
		adoptCheck = function(agentID, sia, u, pbc, pp, quarter, SECADadoptStatus_vec){
			
			dBugSubstep(sprintf("AdoptCheck for Agent: %d", agentID))
			
			if (params$SECADAttitudeModule == "On") {
			dBugSubstep(sprintf("AdoptCheck sia: %f for agent: %d", sia, agentID))
			dBugSubstep(sprintf("AdoptCheck siaThresh: %f", params$SECAD_FIT_siaThresh))
			dBugSubstep(sprintf("AdoptCheck pbc: %f for agent: %d", pbc, agentID))
			dBugSubstep(sprintf("AdoptCheck pp: %f for agent: %d", pp, agentID))
			dBugSubstep(sprintf("AdoptCheck adopt status: %d", SECADadoptStatus_vec[agentID], agentID))	

				if ((sia >= params$SECAD_FIT_siaThresh) & (pbc >= pp) & (SECADadoptStatus_vec[agentID] == 0)) {
					a = 1
					u = u
					sia = sia
				} else {
					a = 0
					sia = sia 										# Original value passed to function
					u = u 		
				}
			} else if (params$SECADAttitudeModule == "Off") {
				if ((pbc >= pp) & (SECADadoptStatus_vec[agentID] == 0)) {
					a = 1
					u = u
					sia = sia
				} else {
					a = 0
					sia = sia 										# Original value passed to function
					u = u 		
				}
			}
			return(c(a,sia,u))
		}
		
		#-----------------------#
		# Knows Any Adopters?
		#-----------------------#
		# Returns T,F

		knowsAdopters = function(SECADagentIndex_vec, SECADadoptStatus_vec){
#			conIndAd = as.logical(SECADadoptStatus_vec[conInd])
			aware_vec = rep(FALSE, length(SECADadoptStatus_vec))

			for (agent in SECADagentIndex_vec){
				alters = unlist(SECADAlter_vec[agent])
				aware_vec[agent] = sum(SECADadoptStatus_vec[alters], na.rm = TRUE) > 0
			}
			return(aware_vec)
		}
			
		
		
		
		
		#####------------------------#
		### Step Function  
		#####------------------------#	
		# This is the agent-level workhorse. Takes one argument,(agentID) which is an agent.
		# Run relative agreement, return a vector of the outcome
		step = function(agentID, quarter, SECADSIA_vec, SECADU_vec, SECADadoptStatus_vec, SECADPBC_vec, PP_vec){
			
			dBugSubstep(sprintf("Stepping on Agent: %d", agentID))
			dBugSubstep(sprintf("Stepping, Agent: %d Adopt status is %d", agentID, SECADadoptStatus_vec[agentID]))
						
			
			if (SECADadoptStatus_vec[agentID] == 0) { # Make sure agent is not an adopter already
				ra = relativeAgreement(agentID, SECADSIA_vec, SECADU_vec, SECADadoptStatus_vec) # Return two part vector. ra[1] is SIA, ra[2] is Uncertainty
		
				pbc = SECADPBC_vec[agentID]
				pp = PP_vec[agentID]
				# Check to see whether household should become an adopter. 
				# Takes the household number and updated SIA from Relative Agreement ra(), and PBC.
				step_vec = adoptCheck(agentID, ra[1], ra[2], pbc, pp, quarter, SECADadoptStatus_vec) # ra[1] is SIA, ra[2] is U
# 				SECADadoptStatus_vec[agentID] <<- step_vec[1]
# 				SECADSIA_vec[agentID] <<- step_vec[2]
# 				SECADU_vec[agentID] <<- step_vec[3]
			} else {
				#print(sprintf("Household with hhIndex: %s is already an adopter: %s", hh, AdVec[hh]))
				step_vec = c(SECADadoptStatus_vec[agentID], SECADSIA_vec[agentID], SECADU_vec[agentID]) # If hh is an adopter, pass current Adopttion, SIA, U values
			}
			dBugSubstep(sprintf("Agent: %d step_vec:", agentID))
			dBugSubstep(step_vec)
			return(c(step_vec[1], step_vec[2], step_vec[3])) # Adopt, SIA, Uncertainty
		}
		

	
		#####------------------------#
		### Step through the agents
		#####------------------------#
		
		print(sprintf("[Core]                    There are %s Adopters", sum(SECADadoptStatus_vec)))
		
		dBugStep(head(SECADadoptStatus_vec) )
		
		dBugSubstep("This is knowsadopters:")
		dBugSubstep(head(knowsAdopters(SECADagentIndex_vec, SECADadoptStatus_vec) ) )
		dBugSubstep(length(knowsAdopters(SECADagentIndex_vec, SECADadoptStatus_vec) ) )
		dBugSubstep(length(!SECADadoptStatus_vec ) )
		
		aware_nonA_vec = (knowsAdopters(SECADagentIndex_vec, SECADadoptStatus_vec) & !SECADadoptStatus_vec)
		print(sprintf("[Core]                    %s Non-Adopter agents aware of solar", sum(aware_nonA_vec)))
		
		dBugRun(sprintf("SECADagentIndex_vec length: %d", length(SECADagentIndex_vec)))
		dBugRun(sprintf("SECADadoptStatus_vec sum: %f", sum(SECADadoptStatus_vec)))
		dBugRun(sprintf("SECADSIA_vec mean: %f", mean(SECADSIA_vec)))
		dBugRun(sprintf("SECADU_vec mean: %f", mean(SECADU_vec)))
		dBugRun(sprintf("SECADPBC_vec mean: %f", mean(SECADPBC_vec)))
		dBugRun(length(SECADadoptStatus_vec))
		dBugRun(length(SECADagentIndex_vec[SECADadoptStatus_vec == 1]))
		dBugRun(length(SECADagentIndex_vec))
		
		step_vec <- lapply(SECADagentIndex_vec[aware_nonA_vec],
			step,
			quarter = q, 
			SECADSIA_vec = SECADSIA_vec, 
			SECADU_vec = SECADU_vec, 
			SECADadoptStatus_vec = SECADadoptStatus_vec,  
			SECADPBC_vec = SECADPBC_vec, 
			PP_vec = PP_vec)

# 		lapply(SECADagentIndex_vec[aware_nonA_vec],
# 			step,
# 			quarter = q, 
# 			SECADSIA_vec = SECADSIA_vec, 
# 			SECADU_vec = SECADU_vec, 
# 			SECADadoptStatus_vec = SECADadoptStatus_vec,  
# 			SECADPBC_vec = SECADPBC_vec, 
# 			PP_vec = PP_vec)
		
		print("[Core]                    Step done, updating ...")
		
		dBugRun(sprintf("Length of step_vec: %d",length(step_vec)))
#		dBugRun(length(na.omit(step_vec)))
		dBugRun(head(na.omit(step_vec)))
		dBugRun(sprintf("Length of SECADagentIndex_vec[aware_nonA_vec]: %d",length(SECADagentIndex_vec[aware_nonA_vec])))

#------------------------------ This part: Redo it.
		sv = unlist(step_vec)

		dBugRun(length(sv[seq(1, length(sv), )]))
		dBugRun(head(sv[seq(1, length(sv), by = 3)]))
		dBugRun(head(seq(1, length(sv), by = 3)))

		dBugRun(length(sv[seq(2, length(sv), )]))
		dBugRun(head(sv[seq(2, length(sv), by = 3)]))
		dBugRun(head(seq(2, length(sv), by = 3)))

		dBugRun(length(sv[seq(3, length(sv), )]))
		dBugRun(head(sv[seq(3, length(sv), by = 3)]))
		dBugRun(head(seq(3, length(sv), by = 3)))

		SECADadoptStatus_vec[SECADagentIndex_vec[aware_nonA_vec]] <<- sv[seq(1, length(sv), by = 3)]
		SECADSIA_vec[SECADagentIndex_vec[aware_nonA_vec]] <<- sv[seq(2, length(sv), by = 3)]	# Update sia, regardless of budget
		SECADU_vec[SECADagentIndex_vec[aware_nonA_vec]] <<- sv[seq(3, length(sv), by = 3)]
		
		stepnewAdopters <<- SECADagentIndex_vec[aware_nonA_vec & SECADadoptStatus_vec]
		AttActiv_vec <<- SECADSIA_vec >= params$SECAD_FIT_siaThresh 
		
		quartnewAdopters <<- quartnewAdopters + length(stepnewAdopters)
		
		print(sprintf("[Core]                    There are %s Economically Activated agents", sum(EconActiv_vec)))
		print(sprintf("[Core]                    There are %s Attitudinally Activated agents", sum(AttActiv_vec)))
		print(sprintf("[Core]                    There are %s New Adopters this step", length(stepnewAdopters)))
		print(sprintf("[Core]                    There are %s Total New Adopters this quarter", quartnewAdopters))

		
	}#------End of SECAD update step
}#------End of SECAD update function







#-----------------------------#
# Create Runtime Routine
#-----------------------------#

runModel <- function (subModelID) {	
	
	print("[Core]          Staging runtime modules")

	if (params$RuntimeInitMod == "SECAD") {
		SECADRuntimeStaging()
	}#------End of SECAD Social Net init check
	
	print("[Core]          Runtime module staging complete")
	
	for(q in 1:params$Quarters) {
		print(sprintf("[Core]          Running Quarter %d", q))
		
		if ("SECAD" %in% params$AdoptRunMod) {
			quartnewAdopters <<- 0
			SECADupdate(subModelID, q)
			if (params$QuartersOut == "On") {
				ModelType = params$ModelType
				ModelNum = params$Model
				Runtime = "SECAD"
				Quarter = q
				CumulAdopts = sum(SECADadoptStatus_vec)
				NewAdopts = quartnewAdopters
				EconActivated = sum(EconActiv_vec)
				AttActivated = sum(AttActiv_vec)
				EmpGrowRate = as.numeric(NewAdopts/CumulAdopts)
							
				tmpQuarterOuts = cbind(ModelType, ModelNum, Runtime, subModelID, Quarter, CumulAdopts, NewAdopts, EconActivated, AttActivated, EmpGrowRate)
				
				dBugRun("printing tmpQuarterOuts")
				dBugRun(tmpQuarterOuts)
				
				QuarterOuts <<- rbind(QuarterOuts, tmpQuarterOuts)
			}#------End of output check	
		}#------End of SECAD check
	}#------End of Quarter increment
	print("[Core]                    Runtime ENDED")
	
}#------End of runModel


